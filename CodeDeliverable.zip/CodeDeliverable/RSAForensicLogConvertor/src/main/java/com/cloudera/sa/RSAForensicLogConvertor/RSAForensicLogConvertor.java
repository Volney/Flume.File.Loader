package com.cloudera.sa.RSAForensicLogConvertor;

import java.io.IOException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.SequenceFile.CompressionType;
import org.apache.hadoop.io.compress.SnappyCodec;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;


public class RSAForensicLogConvertor {

	public static class CustomReducer extends Reducer<Text, Text, NullWritable, Text>
	{

		@Override
		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException
		{
			for (Text value: values)
			{
				context.write(NullWritable.get(), value);
			}
		}
	}
	
	public static class CustomMapper extends Mapper<LongWritable, Text, Text, Text>
	{
		Text newKey = new Text();
		Text newValue = new Text();
		char del = 0; 

		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
		{
			Path path = ((FileSplit)context.getInputSplit()).getPath();
			try
			{	
				RSAForensicPojo p = new RSAForensicPojo(value.toString());
				
				String valOutput = path.getName() + del + 
						           p.getTimestamp() + del +
						           p.getUnixTimestamp() + del +
						           p.getExternalSessionId() + del +
						           p.getRsaSessionId() + del +
						           p.getFactShortCode() + del +
						           p.getLineType();
				
				newKey.set(path.getName());
				newValue.set(valOutput);
				context.write(newKey, newValue);
				
			} catch (Exception e)
			{
				context.getCounter("Mapper", "Exception-" ).increment(1);
				throw new RuntimeException(e);
			}
		}
	}
	
	public static void main(String[] args) throws IOException, InterruptedException, ClassNotFoundException 
	{
		if (args.length != 3 || args[0].contains("-h"))
		{
			System.out.println("RSAForensicLogConvertor <inputPath> <outputPath> <numberOfReducers>");
			System.out.println();
			System.out.println("RSAForensicConvertor input output 3");
			return;
		}

		//Get values from args
		String inputPath = args[0];
		String outputPath = args[1];
		int numberOfReducers = Integer.parseInt(args[2]);
		
		//Create job
		Job job = new Job();
		job.setJarByClass(RSAForensicLogConvertor.class);  //comment for job tracker
		//Define input format and path
		job.setInputFormatClass(TextInputFormat.class); //SequenceFile RCFile Avro
		FileInputFormat.addInputPath(job, new Path(inputPath)); //input path
		
		job.setOutputFormatClass(SequenceFileOutputFormat.class);
		SequenceFileOutputFormat.setOutputPath(job, new Path(outputPath));
		SequenceFileOutputFormat.setOutputCompressionType(job,
				CompressionType.BLOCK);
		SequenceFileOutputFormat.setOutputCompressorClass(job,
				SnappyCodec.class);
		
		//Define output format and path
		//job.setOutputFormatClass(TextOutputFormat.class);
		//FileOutputFormat.setOutputPath(job, new Path(outputPath));
		
		// Define the mapper and reducer
		job.setMapperClass(CustomMapper.class);
		job.setReducerClass(CustomReducer.class);

		// Define the key and value format
		job.setOutputKeyClass(NullWritable.class); 
		job.setOutputValueClass(Text.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);

		job.setNumReduceTasks(numberOfReducers);

		// Exit
		job.waitForCompletion(true);

	}

}
