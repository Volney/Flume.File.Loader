package com.cloudera.sa.RSAForensicLogConvertor;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Pattern;


/**
 * 
 * yyyy-MM-dd HH:mm:ss
 * 2011-11-16 00:00:00 |	{timestamp}

 * */

public class RSAForensicPojo{


    public static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	public static final Pattern p = Pattern.compile("\\|");
	
	Date timestamp = new Date();
	Date unixtimestamp = new Date();
	String external_session_id;
	String rsa_session_id;
	String fact_short_code;
	String line_type;	
	
    protected String workingLine;
	
	protected String pullOutNextIndex(char c)
	{
		int index = workingLine.indexOf(c);
		if (index > -1)
		{
			String result = workingLine.substring(0, index);
			workingLine = workingLine.substring(index + 1);
			return result;
		}else
		{
			return "null";
		}
	}
	
	public RSAForensicPojo(){
	}
	
	public RSAForensicPojo(String line) throws ParseException{
		workingLine = line;
		try {
			timestamp = sdf.parse((pullOutNextIndex(',')));
		} catch (Exception e) {
			timestamp = new Date(0);
		}
		unixtimestamp = new java.util.Date((long)timestamp.getTime()*1000);
		external_session_id = pullOutNextIndex(' ');
		rsa_session_id = pullOutNextIndex(' ');
		fact_short_code = pullOutNextIndex(' ');
		line_type = pullOutNextIndex(' ');
	}

	public Date getTimestamp() {
		return timestamp;
	}
	
	public Date getUnixTimestamp() {
		return unixtimestamp;
	}

	public String getExternalSessionId() {
		return external_session_id;
	}
	
	public String getRsaSessionId() {
		return rsa_session_id;
	}
	
	public String getFactShortCode() {
		return fact_short_code;
	}
	
	public String getLineType() {
		return line_type;
	}

	public String getWorkingLine() {
		return workingLine;
	}
	
}
