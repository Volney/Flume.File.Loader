package com.cloudera.sa.authauditconvertor;

import java.io.IOException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.SequenceFile.CompressionType;
import org.apache.hadoop.io.compress.SnappyCodec;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;


public class AuthAuditLogConvertor {

	public static class CustomReducer extends Reducer<Text, Text, NullWritable, Text>
	{

		@Override
		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException
		{
			for (Text value: values)
			{
				context.write(NullWritable.get(), value);
			}
		}
	}
	
	
	
	public static class CustomMapper extends Mapper<LongWritable, Text, Text, Text>
	{
		Text newKey = new Text();
		Text newValue = new Text();
		char del = 0; 

		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
		{
			Path path = ((FileSplit)context.getInputSplit()).getPath();
			try
			{	
				AuthAuditPojo p = new AuthAuditPojo(value.toString());
				
				String valOutput = path.getName() + del + 
						           p.getTimestamp() + del +
								   p.getMsg1() + del +
						           p.getRequestId() + del +
						           p.gettId() + del +
						           p.getmId() + del + 
						           p.getMmId() + del +
						           p.getGrantor() + del + 
						           p.getRole() + del +
						           p.getMsg2() + del +
						           p.getMsg3() + del + 
						           p.getMsg4() + del + 
						           p.getMsg5() + del + 
						           p.getPhase() + del +
						           p.getUserId() + del +
						           p.getMethod() + del +
						           p.getUnixTimeStamp() + del +
						           p.getUnixDate() + del +
						           p.getStatus() + del +
						           p.getSessionId() + del +
						           p.getIpAddress() + del +
						           p.getRefer() + del +
						           p.getClientSys() + del +
						           p.getGateway1() + del +
						           p.getGateway2() + del +
						           p.getCustomerType() + del +
						           p.getMethodState() + del +
						           p.getMsg6() + del +
						           p.getUrl() + del +
						           p.getMsg7();
				
				newKey.set(path.getName());
				newValue.set(valOutput);
				context.write(newKey, newValue);
				
			} catch (Exception e)
			{
				context.getCounter("Mapper", "Exception-" + path ).increment(1);
				throw new RuntimeException(e);
			}
		}
	}
	
	public static void main(String[] args) throws IOException, InterruptedException, ClassNotFoundException 
	{
		if (args.length != 3 || args[0].contains("-h"))
		{
			System.out.println("AuditLogConvertor <inputPath> <outputPath> <numberOfReducers>");
			System.out.println();
			System.out.println("AuditLogConvertor input output 3");
			return;
		}

		//Get values from args
		String inputPath = args[0];
		String outputPath = args[1];
		int numberOfReducers = Integer.parseInt(args[2]);
		
		//Create job
		Job job = new Job();
		job.setJarByClass(AuthAuditLogConvertor.class);  //comment for job tracker
		//Define input format and path
		job.setInputFormatClass(TextInputFormat.class); //SequenceFile RCFile Avro
		FileInputFormat.addInputPath(job, new Path(inputPath)); //input path
		
		job.setOutputFormatClass(SequenceFileOutputFormat.class);
		SequenceFileOutputFormat.setOutputPath(job, new Path(outputPath));
		SequenceFileOutputFormat.setOutputCompressionType(job,
				CompressionType.BLOCK);
		SequenceFileOutputFormat.setOutputCompressorClass(job,
				SnappyCodec.class);
		
		//Define output format and path
		//job.setOutputFormatClass(TextOutputFormat.class);
		//FileOutputFormat.setOutputPath(job, new Path(outputPath));
		
		// Define the mapper and reducer
		job.setMapperClass(CustomMapper.class);
		job.setReducerClass(CustomReducer.class);

		// Define the key and value format
		job.setOutputKeyClass(NullWritable.class); 
		job.setOutputValueClass(Text.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);

		job.setNumReduceTasks(numberOfReducers);

		// Exit
		job.waitForCompletion(true);

	}

}
