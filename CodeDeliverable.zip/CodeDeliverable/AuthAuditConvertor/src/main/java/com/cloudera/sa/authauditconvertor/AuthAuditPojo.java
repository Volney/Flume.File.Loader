package com.cloudera.sa.authauditconvertor;

public class AuthAuditPojo {

	String timestamp;
	String msg1;
	String requestId;
	String logType;
	String tId;
	String mId;
	String mmId;
	String grantor;
	String role;
	String msg2;
	String msg3;
	String msg4;
	String msg5;
	String phase;
	String userId;
	String method;
	String unixTimeStamp;
	String unixDate;
	String status;
	String sessionId;
	String ipAddress;
	String refer;
	String clientSys;
	String gateway1;
	String gateway2;
	String customerType;
	String methodState;
	String msg6;
	String url;
	String msg7;
	
	protected String workingLine;
	
	protected String pullOutNextIndex(char c)
	{
		int index = workingLine.indexOf(c);
		if (index > -1)
		{
			String result = workingLine.substring(0, index);
			workingLine = workingLine.substring(index + 1);
			return result;
		}else
		{
			return "null";
		}
	}
	
	public AuthAuditPojo(){
		
	}
	
	//2012-09-08 00:16:34,163 [WebContainer : 75] INFO  REQ504ac6a20a024435200016bb000eaa33 - logging:A_TranLog - 50418aa20a042830200044b80004aa33 ee6d7bdefa7c0c11d6b90f9bc8b54aaa77 - 1347077493 Fidelity FidCust - 06 - - - Begin \"-\" Logout 1347077794 27-08-2012 CONTINUE 504ac5740a5d47ad200030310007aa330000 99.12.68.26 \"https://oltx.fidelity.com/ftgw/fbc/ofpositions/brokerageAccountPositions\" \"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/534.57.2 (KHTML  like Gecko) Version/5.1.7 Safari/534.57.2\" /ftgw/Fidelity/RtlCust/Logout/Init - login.fidelity.com -
	public AuthAuditPojo(String line){
		workingLine = line;
		timestamp = pullOutNextIndex(',');
		msg1 = pullOutNextIndex(' ') + " " + pullOutNextIndex(' ') + " " + pullOutNextIndex(' ') + " " + pullOutNextIndex(' ') + " " + pullOutNextIndex(' ');
		pullOutNextIndex(' ');
		requestId = pullOutNextIndex(' ');
		pullOutNextIndex(' ');
		logType = pullOutNextIndex(' ');
		pullOutNextIndex(' ');
		tId = pullOutNextIndex(' ');
		mId = pullOutNextIndex(' ');
		pullOutNextIndex(' ');
		mmId = pullOutNextIndex(' ');
		grantor = pullOutNextIndex(' ');
		role = pullOutNextIndex(' ');
		pullOutNextIndex(' ');
		msg2 = pullOutNextIndex(' ');
		msg3 = pullOutNextIndex(' ');
		msg4 = pullOutNextIndex(' ');
		msg5 = pullOutNextIndex(' ');
		phase = pullOutNextIndex(' ');
		userId = pullOutNextIndex(' ');
		method = pullOutNextIndex(' ');
		unixTimeStamp = pullOutNextIndex(' ');
		unixDate = pullOutNextIndex(' ');
		status = pullOutNextIndex(' ');
		sessionId = pullOutNextIndex(' ');
		ipAddress = pullOutNextIndex(' ');
		pullOutNextIndex('"');
		refer = pullOutNextIndex('"');
		pullOutNextIndex('"');
		clientSys = pullOutNextIndex('"');
		pullOutNextIndex('/');
		gateway1 = pullOutNextIndex('/');
		gateway2 = pullOutNextIndex('/');
		customerType = pullOutNextIndex('/');
		pullOutNextIndex('/');
		methodState = pullOutNextIndex(' ');
		msg6 = pullOutNextIndex(' '); // RSA Event
		url = pullOutNextIndex(' ');
		msg7 = workingLine.trim();
	}
	
	

	public String getTimestamp() {
		return timestamp;
	}

	public String getMsg1() {
		return msg1;
	}

	public String getRequestId() {
		return requestId;
	}

	public String getLogType() {
		return logType;
	}

	public String gettId() {
		return tId;
	}

	public String getmId() {
		return mId;
	}

	public String getMmId() {
		return mmId;
	}

	public String getGrantor() {
		return grantor;
	}

	public String getRole() {
		return role;
	}

	public String getMsg2() {
		return msg2;
	}

	public String getMsg3() {
		return msg3;
	}

	public String getMsg4() {
		return msg4;
	}

	public String getMsg5() {
		return msg5;
	}

	public String getPhase() {
		return phase;
	}

	public String getUserId() {
		return userId;
	}

	public String getMethod() {
		return method;
	}

	public String getUnixTimeStamp() {
		return unixTimeStamp;
	}

	public String getUnixDate() {
		return unixDate;
	}

	public String getStatus() {
		return status;
	}

	public String getSessionId() {
		return sessionId;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public String getRefer() {
		return refer;
	}

	public String getClientSys() {
		return clientSys;
	}

	public String getGateway1() {
		return gateway1;
	}

	public String getGateway2() {
		return gateway2;
	}

	public String getCustomerType() {
		return customerType;
	}

	public String getMethodState() {
		return methodState;
	}

	public String getMsg6() {
		return msg6;
	}

	public String getUrl() {
		return url;
	}

	public String getMsg7() {
		return msg7;
	}

	public String getWorkingLine() {
		return workingLine;
	}
	
}
