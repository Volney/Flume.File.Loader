package com.cloudera.sa.regex;

public abstract class AbstractConvertorPojo {


	protected String workingLine;
	
	protected String pullOutNextIndex(char c)
	{
		int index = workingLine.indexOf(c);
		if (index > -1)
		{
			String result = workingLine.substring(0, index);
			workingLine = workingLine.substring(index + 1);
			return result;
		}else
		{
			return "null";
		}
	}

}
