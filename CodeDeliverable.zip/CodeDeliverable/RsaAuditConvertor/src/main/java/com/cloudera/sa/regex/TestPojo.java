package com.cloudera.sa.regex;

import java.text.ParseException;

public class TestPojo {

	/**
	 * @param args
	 * @throws ParseException 
	 */
	public static void main(String[] args) throws ParseException {
		//AuthAuditPojo p = new AuthAuditPojo("2012-09-08 00:16:34,163 [WebContainer : 75] INFO  REQ504ac6a20a024435200016bb000eaa33 - logging:A_TranLog - 50418aa20a042830200044b80004aa33 ee6d7bdefa7c0c11d6b90f9bc8b54aaa77 - 1347077493 Fidelity FidCust - 06 - - - Begin \"-\" Logout 1347077794 27-08-2012 CONTINUE 504ac5740a5d47ad200030310007aa330000 99.12.68.26 \"https://oltx.fidelity.com/ftgw/fbc/ofpositions/brokerageAccountPositions\" \"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/534.57.2 (KHTML  like Gecko) Version/5.1.7 Safari/534.57.2\" /ftgw/Fidelity/RtlCust/Logout/Init - login.fidelity.com -");

		//System.out.println(p.getGrantor());
		
		RSAAuditPojo p = new RSAAuditPojo("2012-07-27 00:00:00,638 -0400 | [] | [6e3c4fa4:138c6972752:-7fe8] | [6400EC755B7000A3DDEDC6D4B40B5E3AE7B0F6DD | Fidelity | 564867431 | 71.54.139.24 | b4jLQWM4KUVINZz7rtzUFaIp6jU= | AUTH_RESULT | EVENTID_UNDEFINED | TRANSID_UNDEFINED | TRANSTYPE_UNDEFINED | [&AUTH_RESULT_RESULT=FAIL&AUTH_RESULT_RISK=0&CREDENTIAL_TYPE=DEVICE]]");
		
		p.getDeviceId();
	}

}
