package com.cloudera.sa.regex;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Pattern;

/**
 * 
 * yyyy-MM-dd HH:mm:ss
 * 2011-11-16 00:00:00, 085 -0500 |				{timestamp,webcontainer}
[] | 											{external_session_id}
[-57e4f42c:133a85d733f:7975] | 					{pm_session_id} 
[CE6929398C3812601CE77C8805B901561A46B9E0 | 	{user_id}
 nf | 											{org}
1817088658 | 									{device_id}
10.93.73.52 | 									{ip}
LePUY+2uxTy6lfP03ikXmTz4epw= | 					{hashed_ip}	
AUTH_RESULT | 									{event_type}
EVENTID_UNDEFINED | 							{event_id}
TRANSID_UNDEFINED | 							{transaction_id}
TRANSTYPE_UNDEFINED | 							{transaction_type}
[&AUTH_RESULT_RESULT=FAIL&AUTH_RESULT_RISK=0&CREDENTIAL_TYPE=DEVICE]] {key_val_sets} //additional info


 * */

public class RSAAuditPojo extends AbstractConvertorPojo{


    public static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	
	public static final Pattern p = Pattern.compile("\\|");
	
	Date timestamp = new Date();
	String webcontainer;
	Long unixtimestamp;
	String sessionKey;
	String rsaSessionKey;
	String user_id;
	String org;
	String device_id;
	String ip;
	String hashed_ip;
	String event_type;
	String event_id;
	String transaction_id;
	String transaction_type;
	String key_val_sets;	
	
	public RSAAuditPojo(){
	}
	
	public RSAAuditPojo(String line) throws ParseException{
		workingLine = line;
		try {
			timestamp = sdf.parse((pullOutNextIndex(',')));
		} catch (Exception e) {
			timestamp = new Date(0);
		}
//2012-07-27 00:00:00,638 -0400 | [] | [6e3c4fa4:138c6972752:-7fe8] | [6400EC755B7000A3DDEDC6D4B40B5E3AE7B0F6DD | Fidelity | 564867431 | 71.54.139.24 | b4jLQWM4KUVINZz7rtzUFaIp6jU= | AUTH_RESULT | EVENTID_UNDEFINED | TRANSID_UNDEFINED | TRANSTYPE_UNDEFINED | [&AUTH_RESULT_RESULT=FAIL&AUTH_RESULT_RISK=0&CREDENTIAL_TYPE=DEVICE]]
		unixtimestamp = timestamp.getTime();
		webcontainer = pullOutNextIndex('|').trim();
		pullOutNextIndex('[');
		sessionKey = pullOutNextIndex(']');
		pullOutNextIndex('[');
		rsaSessionKey = pullOutNextIndex(']');
		pullOutNextIndex('|');
		pullOutNextIndex(' ');
		user_id = pullOutNextIndex(' ');
		pullOutNextIndex(' ');
		org = pullOutNextIndex(' ');
		pullOutNextIndex(' ');
		device_id = pullOutNextIndex(' ');
		pullOutNextIndex(' ');
		ip = pullOutNextIndex(' ');
		pullOutNextIndex(' ');
		hashed_ip = pullOutNextIndex(' ');
		pullOutNextIndex(' ');
		event_type = pullOutNextIndex(' ');
		pullOutNextIndex(' ');
		event_id = pullOutNextIndex(' ');
		pullOutNextIndex(' ');
		transaction_id = pullOutNextIndex(' ');
		pullOutNextIndex(' ');
		transaction_type = pullOutNextIndex(' ');
		pullOutNextIndex(' ');
		key_val_sets = workingLine;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public String getWebcontainer() {
		return webcontainer;
	}

	public void setWebcontainer(String webcontainer) {
		this.webcontainer = webcontainer;
	}

	public Long getUnixtimestamp() {
		return unixtimestamp;
	}

	public void setUnixtimestamp(Long unixtimestamp) {
		this.unixtimestamp = unixtimestamp;
	}

	public String getSessionKey() {
		return sessionKey;
	}

	public void setSessionKey(String sessionKey) {
		this.sessionKey = sessionKey;
	}

	public String getRsaSessionKey() {
		return rsaSessionKey;
	}

	public void setRsaSessionKey(String rsaSessionKey) {
		this.rsaSessionKey = rsaSessionKey;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getOrg() {
		return org;
	}

	public void setOrg(String org) {
		this.org = org;
	}

	public String getDevice_id() {
		return device_id;
	}

	public void setDevice_id(String device_id) {
		this.device_id = device_id;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getHashed_ip() {
		return hashed_ip;
	}

	public void setHashed_ip(String hashed_ip) {
		this.hashed_ip = hashed_ip;
	}

	public String getEvent_type() {
		return event_type;
	}

	public void setEvent_type(String event_type) {
		this.event_type = event_type;
	}

	public String getEvent_id() {
		return event_id;
	}

	public void setEvent_id(String event_id) {
		this.event_id = event_id;
	}

	public String getTransaction_id() {
		return transaction_id;
	}

	public void setTransaction_id(String transaction_id) {
		this.transaction_id = transaction_id;
	}

	public String getTransaction_type() {
		return transaction_type;
	}

	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}

	public String getKey_val_sets() {
		return key_val_sets;
	}

	public void setKey_val_sets(String key_val_sets) {
		this.key_val_sets = key_val_sets;
	}
	
	
}
