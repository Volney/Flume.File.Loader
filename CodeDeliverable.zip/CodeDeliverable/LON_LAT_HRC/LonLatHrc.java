import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.StringTokenizer;
import org.apache.commons.io.FileUtils;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.util.*;

public class LonLatHrc extends Configured implements Tool {
  public static void main(String[] args) throws Exception {
    int res = ToolRunner.run(new Configuration(), new LonLatHrc(), args);
    System.exit(res);
  }

  public int run(String[] args) throws Exception {
    boolean isDebug = java.lang.management.ManagementFactory.getRuntimeMXBean()
        .getInputArguments().toString().indexOf("-agentlib:jdwp") > 0;
    Date gatewaydate = new Date();

    String strInputPaths = "hdfs://h12.demo.dev:8020/user/drule/ttndbo/cus_fact,hdfs://h12.demo.dev:8020/user/drule/ttndbo/exceptions_sess,hdfs://h12.demo.dev:8020/user/drule/ttndbo/auth_logs_starq";
    String strOutputPath = "/home/drule/workspace/TempHrc/LON-LAT-HRC-HIT/"
        + (new SimpleDateFormat("yyyy-MM-dd")).format(gatewaydate);
    // String opt_date = ;
    if (isDebug) {
      ((Runtime.getRuntime()).exec("rm -fr " + strOutputPath)).waitFor();
    }
    // config and Execute
    {
      JobConf conf = new JobConf(getConf(), LonLatHrc.class);
      // custom
      if (conf.get("opt_date", "").equals("")) {
        conf.set("opt_date",
            (new SimpleDateFormat("yyyy-MM-dd")).format(gatewaydate));
      }
      conf.setPartitionerClass(MidDatePartitioner.class);
      // debug only
      if (isDebug) {
        conf.set("opt_date", "2012-10-31");
      }
      // hadoop
      conf.setJobName("DebugMapred");
      conf.setOutputKeyClass(BytesWritable.class);
      conf.setOutputValueClass(Text.class);
      conf.setMapperClass(MapClass.class);
      conf.setReducerClass(Reduce.class);
      if (isDebug) {
        conf.setNumMapTasks(1);
        conf.setNumReduceTasks(1);
        FileInputFormat.setInputPaths(conf, strInputPaths);
        FileOutputFormat.setOutputPath(conf, new Path(strOutputPath));
      }
      RunningJob job = JobClient.runJob(conf);
      job.waitForCompletion();
    }
    // Display first part to stdout when run in a debugger
    if (isDebug) {
      File fileTemp = new File(strOutputPath + "/part-00000");
      if (fileTemp.exists()) {
        System.out.println(FileUtils.readFileToString(fileTemp));
      }
    }
    return 0;
  }

  public static class MapClass extends MapReduceBase implements
      Mapper<LongWritable, Text, BytesWritable, Text> {
    private JobConf conf;

    @Override
    public void configure(JobConf conf) {
      this.conf = conf;
    }
    /**
     * This mapper handles 3 heterogeneous types of input files cus_fact, 
     * exceptions_sess and auth_logs_starq and produces key-value pairs.
     * If the input is from cus_fact or exceptions_sess then a fake epoch is
     * put into the key in order to ensure that come before the keys with real
     * epocs. In all cases, the output key contains two big endian longs.
     * Because mid is the lower subscript long, the key-value-pairs will first
     * be sorted by mid then secondly by epoch. For example if mid some tuples
     * of the input data consisting of 1 cus_fact, 2 exceptions_sess, and 2
     * auth_logs_starq, then the resulting order after sort is:
     *  (mid, cus_fact) -> 1 value
     *  (mid, exceptions_sess) -> 2 values
     *  (mid, auth_logs_starq) -> 2 values (in reverse chronological order)
     *  
     *  This will allow the reducer to complete the following tasks in order
     *  and more importantly, in a single pass through the values associated with
     *  an mid.
     *  1. get count of cust_fact for current mid (this came first because epoch was 0)
     *  2. get count of exceptions_sess for current mid (this came second because epoch was 1)
     *  3. Iterate auth_logs_starq in reverse chronological order (this came last because epoch was > 1)
     *  
     *  Note: this means the input data must never contain an epoch with the value 0 or 1
     *        if such a case must be supported, will need to add an extra byte to the beginning of they
     *        key to handle this.
     * 
     *  map input schema:
     *  if path contains "/cus_fact/"
     *    mid fact_id rule_id
     *  if path contains "/exceptions_sess/"
     *    mid rule_id
     *  if path contains "/auth_logs_starq/"
     *    mid country_iso date time tid ipAddr cid session_key epoch latitude longitude carrier
     *  
     * map output key:
     *  if path contains "/cus_fact/"
     *    mid 0
     *  if path contains "/exceptions_sess/"
     *    mid 1
     *  if path contains "/auth_logs_starq/"
     *    mid (Long.MAX_VALUE - epoch)
     *      Note: This ensures reverse chronological ordering
     *  
     * map output value:
     *  if path contains "/cus_fact/"
     *    "c"
     *  if path contains "/exceptions_sess/"
     *    "e"
     *  if path contains "/auth_logs_starq/"
     *    "mid country_iso date time tid ipAddr cid session_key epoch latitude longitude carrier"
     * */
    public void map(LongWritable key, Text value,
        OutputCollector<BytesWritable, Text> output, Reporter reporter)
        throws IOException {
      String line = value.toString();
      String strMapInputFile = conf.get("map.input.file");
      String opt_date = conf.get("opt_date");
      StringTokenizer itr = new StringTokenizer(line);
      BytesWritable packedKey;
      String intervalue = "";
      if (strMapInputFile.indexOf("/cus_fact/") != -1) {
        long mid = Long.parseLong(itr.nextToken());
        String fact_id = itr.nextToken();
        short rule_id = Short.parseShort(itr.nextToken());
        long epoch = 0;
        if (rule_id == 30025 && fact_id.equals(opt_date)) {
          packedKey = PackBigEndianLongLong(mid, epoch);
          intervalue = "c";
          output.collect(packedKey, new Text(intervalue));
        }
      } else if (strMapInputFile.indexOf("/exceptions_sess/") != -1) {
        long mid = Long.parseLong(itr.nextToken());
        short rule_id = Short.parseShort(itr.nextToken());
        long epoch = 1;
        if (rule_id == 30025) {
          packedKey = PackBigEndianLongLong(mid, epoch);
          intervalue = "e";
          output.collect(packedKey, new Text(intervalue));
        }
      } else if (strMapInputFile.indexOf("/auth_logs_starq/") != -1) {
        long mid = Long.parseLong(itr.nextToken());
        itr.nextToken();
        String date = itr.nextToken();
        if (date.equals(opt_date)) {
          itr.nextToken();
          itr.nextToken();
          itr.nextToken();
          itr.nextToken();
          itr.nextToken();
          long epoch = Long.parseLong(itr.nextToken());
          packedKey = PackBigEndianLongLong(mid, Long.MAX_VALUE - epoch);
          intervalue = "a";
          output.collect(packedKey, new Text(value));
        }
      } else {
        throw new IOException(
            "Input path must contain /cus_fact/, /exceptions_sess/ or /auth_logs_starq/  Invalid path at: "
                + strMapInputFile);
      }

    }

    private BytesWritable PackBigEndianLongLong(long arg0, long arg1) {
      byte b[] = new byte[16];
      ByteBuffer buf = ByteBuffer.wrap(b);
      buf.putLong(arg0);
      buf.putLong(arg1);
      BytesWritable ret = new BytesWritable(b);
      return ret;
    }
  }
  public static class MidDatePartitioner implements
      Partitioner<BytesWritable, Text>, Configurable {

    /**
     * Tell hadoop to only look at the mid portion of the key
     * when deciding where to send key-value pairs.
     * 
     * The entire key will still be used for sorting the data
     * including both mid and epoch. 
     * */
    @Override
    public int getPartition(BytesWritable key, Text value, int n) {
      long lMid = UnpackMid(key);
      int iPartition = Math.abs(Long.valueOf(lMid).hashCode() % n);
      return iPartition;
    }

    private long UnpackMid(BytesWritable packed) {
      byte b[] = packed.getBytes();
      ByteBuffer buf = ByteBuffer.wrap(b);
      long arg0 = buf.getLong();
      return arg0;
    }

    @Override
    public void configure(JobConf arg0) {
      // TODO Auto-generated method stub
    }

    @Override
    public Configuration getConf() {
      // TODO Auto-generated method stub
      return null;
    }

    @Override
    public void setConf(Configuration arg0) {
      // TODO Auto-generated method stub
    }

  }

  public static class AuthLogStarq {
    public long mid;
    public String country_iso;
    public String date;
    public String time;
    public String tid;
    public String ipAddr;
    public String cid;
    public String session_key;
    public long epoch;
    public double latitude;
    public double longitude;
    public String carrier;
  }
  public static class Reduce extends MapReduceBase implements
      Reducer<BytesWritable, Text, Text, Text> {

    @Override
    public void configure(JobConf conf) {
      hsIso = new HashSet<String>();
      hsIso.add("ru");
      hsIso.add("my");
      hsIso.add("ro");
      hsIso.add("lt");
      hsIso.add("ng");
      hsIso.add("ua");
      hsIso.add("by");
      hsCarrier = new HashSet<String>();
      hsCarrier.add("yodlee");
      hsCarrier.add("cashedge");
      hsCarrier.add("tellme networks");
    }

    private HashSet<String> hsIso;
    private HashSet<String> hsCarrier;

    private char last_state = 'n';
    private int exceptions_sess = 0;
    private int cust_fact = 0;
    private long last_mid = -1;
    private AuthLogStarq authIso = null;
    private AuthLogStarq authCarrier = null;


    /**
     * Reduce will be executed multiple times for each mid.
     * However, there is a guarantees about order in which reduce will
     * execute because of how the mapper and partitioner are set up:
     * for each mid partitioned to this Reducer instance
     *    1. for each cust_fact
     *      execute reduce()
     *    2. for each exceptions_sess
     *      execute reduce()
     *    3. for each auth_logs_starq (reverse chronological order)
     *      execute reduce()
     *  The same instance of Reduce class will be used for 
     *  multiple different mid's. So we will need to track state.
     * */
    public void reduce(BytesWritable key, Iterator<Text> values,
        OutputCollector<Text, Text> output, Reporter reporter)
        throws IOException {

      long current_mid = -1;
      long epoch = -1;
      {
        byte b[] = key.getBytes();
        ByteBuffer buf = ByteBuffer.wrap(b);
        current_mid = buf.getLong();
        epoch = buf.getLong();
        epoch = Long.MAX_VALUE - epoch;
      }

      if (current_mid != last_mid) {
        exceptions_sess = 0;
        cust_fact = 0;
        authIso = null;
        authCarrier = null;
      }

      char current_state;

      if (epoch == Long.MAX_VALUE - 1) {
        current_state = 'e';
        while (values.hasNext()) {
          values.next();
          ++exceptions_sess;
        }
      } else if (epoch == Long.MAX_VALUE) {
        current_state = 'c';
        while (values.hasNext()) {
          values.next();
          ++cust_fact;
        }
      } else {
        current_state = 'a';
      }

      // for the current mid, are we at auth_logs_starq yet
      if (current_state == 'a' && (last_state == 'e' || last_state == 'a')
          && last_mid == current_mid) {
        // for the current mid, have seen at least 2 exceptions_sess and 1 cust_fact
        // if they exist, we will have seen them by now because they have epoch 0 and 1
        if (exceptions_sess >= 2 && cust_fact >= 1) {
          // most of the time this loop has just 1 iteration because
          // each auth_logs_starq has a different epoch
          // but doing this in a loop just in case there is ever
          // an mid with 2 or more epochs with the same value
          while (values.hasNext()) {
            Text value = values.next();
            String line = value.toString();
            StringTokenizer itr = new StringTokenizer(line);
            AuthLogStarq authCurr = new AuthLogStarq();
            {
              authCurr.mid = Long.parseLong(itr.nextToken());
              authCurr.country_iso = itr.nextToken();
              authCurr.date = itr.nextToken();
              authCurr.time = itr.nextToken();
              authCurr.tid = itr.nextToken();
              authCurr.ipAddr = itr.nextToken();
              authCurr.cid = itr.nextToken();
              authCurr.session_key = itr.nextToken();
              authCurr.epoch = Long.parseLong(itr.nextToken());
              authCurr.latitude = Double.parseDouble(itr.nextToken());
              authCurr.longitude = Double.parseDouble(itr.nextToken());
              authCurr.carrier = itr.nextToken();
            }
            if (authIso == null) {
              if (hsIso.contains(authCurr.country_iso)) {
                authIso = authCurr;
              }
            } else if (authCarrier == null) {
              if (!hsCarrier.contains(authCurr.carrier)) {
                authCarrier = authCurr;
                double distance = latlon_distance(authIso.latitude,
                    authIso.longitude, authCarrier.latitude,
                    authCarrier.longitude);
                if (distance > 2500) {
                  output.collect(null, new Text(Long.toString(authIso.mid)
                      + "\t" + authIso.session_key + "\t" + "LON-LAT:HRC\t"
                      + authIso.date + "TIG\tTIG\t30052\tLON-LAT HIT found"));
                }
              }
            }
          }
        }
      }

      last_state = current_state;
      last_mid = current_mid;
    }

    private double latlon_distance(double a1, double b1, double a2, double b2) {
      double pi = 3.14159; // value for Pi
      double r = 3963.1; // status miles
      // Take input as degrees - and translates them into radians
      a1 = a1 * (pi / 180);
      b1 = b1 * (pi / 180);
      a2 = a2 * (pi / 180);
      b2 = b2 * (pi / 180);

      return Math.acos(Math.cos(a1) * Math.cos(b1) * Math.cos(a2)
          * Math.cos(b2) + Math.cos(a1) * Math.sin(b1) * Math.cos(a2)
          * Math.sin(b2) + Math.sin(a1) * Math.sin(a2))
          * r;

    }



  }

}