package com.cloudera.sa.MoneyLaunderingStreamAnalyzer;

import java.io.IOException;
import java.util.regex.Pattern;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.SequenceFileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;


public class App 
{
	public static class CustomMapper extends Mapper<NullWritable, Text, Text, Text>
	{
		Text newKey = new Text();
		Text newValue = new Text();

		
		@Override
		public void map(NullWritable key, Text value, Context context) throws IOException, InterruptedException
		{
			ClickStreamPojo p = new ClickStreamPojo(value.toString());
			
			if (p.getMid().trim().length() > 3)
			{
				newKey.set(p.getMid() + "|" + p.getClickDate());
				
				context.write(newKey, value);
			}
		}
	}

	public static class CustomReducer extends Reducer<Text, Text, NullWritable, Text>
	{
		Text newValue = new Text();		
		
		public long sessionGapTime = 30 * 60 * 1000;
		
		public String lagMid = "Nothing";
		public long lagClickTime = 0;
		
		Pattern p = Pattern.compile("\\|");
		
		
		
		@Override
		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException
		{
			String[] keySplit = p.split(key.toString());
			String currentMid = keySplit[0];
			Long currentClickTime = Long.parseLong(keySplit[1]);
			
			for (Text value: values)
			{
				MoneyLaunderingStreamAnalyzer(context, currentMid,
						currentClickTime, value);
			}	
		}


		private void MoneyLaunderingStreamAnalyzer(Context context,
				String currentMid, Long currentClickTime, Text value)
				throws IOException, InterruptedException {
			ClickStreamPojo pojo = new ClickStreamPojo(value.toString());
			if (lagMid.equals(currentMid)) {
				//This is the same user
				if (lagClickTime + sessionGapTime < currentClickTime) {
					//new session
					mIdStory.append("(" + ((lagClickTime + sessionGapTime - currentClickTime)/1000/60) + ")");
					endOfSessionWork(pojo, context);
				} 
			} else {
				//This is a new user = new session
				endOfSessionWork(pojo, context);
				newValue.set(lagMid + ":" + mIdStory);
				context.write(NullWritable.get(), newValue);
				
				context.getCounter("Reduce", "MIDs").increment(1);
				
				lagMid = currentMid;
				mIdStory = new StringBuilder();
			}
			
			recordClick(pojo, context);

			lagClickTime = currentClickTime;
		}
		
		private static final String LOG_IN_START_WITH = "login";
		private static final String CREATE_ACCOUNT_START_WITH = "aongapp/";
		private static final String PUT_MONEY_IN_START_WITH = "mm/Trans";
		private static final String TAKE_MONEY_OUT_START_WITH = "mm/mmM";
		
		long lagOpenAccountCount = 0;
		long lagPutMoneyInCount  = 0;
		long lagTakeMoneyOutCount = 0;
		long lagOtherCount = 0;
		
		StringBuilder lagSessionSummary = new StringBuilder();
		StringBuilder mIdStory = new StringBuilder();
		
		String lastLogPutMid = "";
		String lastLogPutSessionSummary = "";
		
		private void recordClick(ClickStreamPojo pojo, Context context) throws IOException, InterruptedException {
			String pageStr = pojo.getRequestPageStr();
			
			lagSessionSummary.append(";" + pojo.clickDate + "," + pageStr);
			
			if (pageStr.contains(CREATE_ACCOUNT_START_WITH)) {
				lagOpenAccountCount++;
				context.getCounter("Reducer", "Create ACCENT").increment(1);
				mIdStory.append("C");
			} else if (pageStr.contains(PUT_MONEY_IN_START_WITH)) {
				lagPutMoneyInCount++;
				context.getCounter("Reducer", "Put Money").increment(1);
				mIdStory.append("P");
			} else if (pageStr.contains(TAKE_MONEY_OUT_START_WITH)) {
				lagTakeMoneyOutCount++;
				context.getCounter("Reducer", "Take Money").increment(1);
				mIdStory.append("T");
			} else if (pageStr.contains(LOG_IN_START_WITH)) {
				endOfSessionWork(pojo, context);
				context.getCounter("Reducer", "Log in").increment(1);
				mIdStory.append("I");
			} else {
				lagOtherCount++;
				mIdStory.append("O");
			}
			
			if(mIdStory.length() > 10000)
			{
				newValue.set(lagMid + ":OVERFLOW:" + mIdStory);
				context.getCounter("Reducer", "OverFull").increment(1);
				context.write(NullWritable.get(), newValue);
				mIdStory = new StringBuilder("Too Big");
				
			}
		}
		
		
		private void endOfSessionWork(ClickStreamPojo pojo, Context context) throws IOException, InterruptedException {
			
			if (isLogInPutSession()){
				lastLogPutMid = pojo.getMid();
				lastLogPutSessionSummary = lagSessionSummary.toString();
			} else if (isLogInTakeSession() && lastLogPutMid.isEmpty() == false && lastLogPutMid.equals(pojo.getMid())) {
				newValue.set(lastLogPutMid + ":" + lastLogPutSessionSummary + "|" + lagSessionSummary.toString());
				context.getCounter("Reducer", "Money Laundering").increment(1);
				context.write(NullWritable.get(), newValue);
			} else if (isOtherSession()) {
				lastLogPutMid = "";	
				lastLogPutSessionSummary = "";
			}
			
			lagSessionSummary = new StringBuilder();
			
		}
		
		private boolean isLogInPutSession() {
			return (lagOpenAccountCount > 0 && lagPutMoneyInCount > 0 && lagTakeMoneyOutCount == 0);
		}
		
		private boolean isLogInTakeSession() {
			return (lagPutMoneyInCount == 0 && lagTakeMoneyOutCount > 0);
		}
		
		private boolean isOtherSession() {
			return (lagPutMoneyInCount == 0 && lagTakeMoneyOutCount == 0 && lagOtherCount > 5);
		}
	}

	public static class CustomPartitioner extends Partitioner<Text, Text>
	{

		Pattern p = Pattern.compile("\\|");
		
		
		@Override
		public int getPartition(Text key, Text value, int numPartitions)
		{
			if (numPartitions == 1)
			{
				return 0;
			} else
			{
				
				String keyString = p.split(key.toString())[0]; 
				
				//If keyString ends in A then it is a page
				int result = (keyString).hashCode() % numPartitions;

				//return absolute value in case hash returns a negative value
				return Math.abs(result);
			}
		}

	}
	
	public static void main(String[] args) throws Exception
	{
		if (args.length != 3)
		{
			System.out.println("MoneyLaunderingStreamAnalyzer <inputPath> <outputPath> <# reducers>");
			System.out.println();
			System.out.println("Example: MoneyLaunderingStreamAnalyzer ./nbbo ./Nbbo_gzip 1");
			return;
		}

		//Get values from args
		String inputPath = args[0];
		String outputPath = args[1];
		String numberOfReducers = args[2];
		
		//Create job
		Job job = new Job();
		job.setJarByClass(App.class);
		//Define input format and path
		job.setInputFormatClass(SequenceFileInputFormat.class);
		
		String[] paths = inputPath.split(",");
		for (String p: paths) {
			SequenceFileInputFormat.addInputPath(job, new Path(p));
		}
		
		//Define output format and path
		job.setOutputFormatClass(SequenceFileOutputFormat.class);
		SequenceFileOutputFormat.setOutputPath(job, new Path(outputPath));
		
		// Define the mapper and reducer
		job.setMapperClass(CustomMapper.class);
		job.setReducerClass(CustomReducer.class);
		job.setPartitionerClass(CustomPartitioner.class);

		// Define the key and value format
		job.setOutputKeyClass(NullWritable.class);
		job.setOutputValueClass(Text.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);

		job.setNumReduceTasks(Integer.parseInt(numberOfReducers));

		// Exit
		job.waitForCompletion(true);
	}

}
