package com.cloudera.sa.MoneyLaunderingStreamAnalyzer;

import java.util.regex.Pattern;

public class ClickStreamPojo {

	public static Pattern p = Pattern.compile("\t");
	
	String filename;
	String clickDate;  
	String Mid;
	String Tid;
	String requestPageStr;
	String requestDynamicStr;
	String referrerPageStr;
	String referrerDynamicStr; 
	String status;
	String userAgent;
	String eSiteSessionKey;
	String febsecSessionKey;
	String sequenceNum;
	String febsecCoAttributes; 
	String ipAddr;
	String mimeMid;
	String relMap;
	String sessionFlag;
	String role;
	String assocFlag;
	String dwellTime;
	
	public ClickStreamPojo(String input) {
		String[] parts = p.split(input);
		
		filename = parts[0];
		clickDate = parts[1];
		Mid = parts[2];
		Tid = parts[3];
		requestPageStr = parts[4];
		requestDynamicStr = parts[5];
		referrerPageStr = parts[6];
		referrerDynamicStr = parts[7];
		status = parts[8];
		userAgent = parts[9];
		eSiteSessionKey = parts[10];
		febsecSessionKey = parts[11];
		sequenceNum = parts[12];
		febsecCoAttributes = parts[13];
		ipAddr = parts[14];
		mimeMid = parts[15];
		relMap = parts[16];
		sessionFlag = parts[17];
		role = parts[18];
		assocFlag = parts[19];
		dwellTime = parts[20];
	}

	public static Pattern getP() {
		return p;
	}

	public String getFilename() {
		return filename;
	}

	public String getClickDate() {
		return clickDate;
	}

	public String getMid() {
		return Mid;
	}

	public String getTid() {
		return Tid;
	}

	public String getRequestPageStr() {
		return requestPageStr;
	}

	public String getRequestDynamicStr() {
		return requestDynamicStr;
	}

	public String getReferrerPageStr() {
		return referrerPageStr;
	}

	public String getReferrerDynamicStr() {
		return referrerDynamicStr;
	}

	public String getStatus() {
		return status;
	}

	public String getUserAgent() {
		return userAgent;
	}

	public String geteSiteSessionKey() {
		return eSiteSessionKey;
	}

	public String getFebsecSessionKey() {
		return febsecSessionKey;
	}

	public String getSequenceNum() {
		return sequenceNum;
	}

	public String getFebsecCoAttributes() {
		return febsecCoAttributes;
	}

	public String getIpAddr() {
		return ipAddr;
	}

	public String getMimeMid() {
		return mimeMid;
	}

	public String getRelMap() {
		return relMap;
	}

	public String getSessionFlag() {
		return sessionFlag;
	}

	public String getRole() {
		return role;
	}

	public String getAssocFlag() {
		return assocFlag;
	}

	public String getDwellTime() {
		return dwellTime;
	}
	
	
}
