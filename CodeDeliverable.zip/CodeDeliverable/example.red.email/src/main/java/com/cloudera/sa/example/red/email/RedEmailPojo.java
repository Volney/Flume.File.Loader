package com.cloudera.sa.example.red.email;

import java.util.StringTokenizer;

public class RedEmailPojo {

	String redEmailId;
	String emailX;
	String ssn;
	String mid;
	String redBatchN;
	String batchSeqN;
	String regSrcN;
	String refSrcTyC;
	String refSrc;
	String refD;
	String caseMgtSys;
	String caseN;
	String caseTY;
	String caseCls;
	String statC;
	String statI;
	String descX;
	String noteTyC;
	String noteX;
	String dbUsrId;
	String updD;
	String strtD;
	String endD;
	
	public RedEmailPojo(String line){
		StringTokenizer st = new StringTokenizer(line, "|");
		redEmailId = st.nextToken();
		emailX = st.nextToken();
		ssn = st.nextToken();
		mid = st.nextToken();
		redBatchN = st.nextToken();
		batchSeqN = st.nextToken();
		regSrcN = st.nextToken();
		refSrcTyC = st.nextToken();
		refSrc = st.nextToken();
		refD = st.nextToken();
		caseMgtSys = st.nextToken();
		caseN = st.nextToken();
		caseTY = st.nextToken();
		caseCls = st.nextToken();
		statC = st.nextToken();
		statI = st.nextToken();
		descX = st.nextToken();
		noteTyC = st.nextToken();
		noteX = st.nextToken();
		dbUsrId = st.nextToken();
		updD = st.nextToken();
		strtD = st.nextToken();
		endD = st.nextToken();
	}

	public String getRedEmailId() {
		return redEmailId;
	}

	public String getEmailX() {
		return emailX;
	}

	public String getSsn() {
		return ssn;
	}

	public String getMid() {
		return mid;
	}

	public String getRedBatchN() {
		return redBatchN;
	}

	public String getBatchSeqN() {
		return batchSeqN;
	}

	public String getRegSrcN() {
		return regSrcN;
	}

	public String getRefSrcTyC() {
		return refSrcTyC;
	}

	public String getRefSrc() {
		return refSrc;
	}

	public String getRefD() {
		return refD;
	}

	public String getCaseMgtSys() {
		return caseMgtSys;
	}

	public String getCaseN() {
		return caseN;
	}

	public String getCaseTY() {
		return caseTY;
	}

	public String getCaseCls() {
		return caseCls;
	}

	public String getStatC() {
		return statC;
	}

	public String getStatI() {
		return statI;
	}

	public String getDescX() {
		return descX;
	}

	public String getNoteTyC() {
		return noteTyC;
	}

	public String getNoteX() {
		return noteX;
	}

	public String getDbUsrId() {
		return dbUsrId;
	}

	public String getUpdD() {
		return updD;
	}

	public String getStrtD() {
		return strtD;
	}

	public String getEndD() {
		return endD;
	}
	
	

}
