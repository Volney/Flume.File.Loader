package com.cloudera.sa.example.red.email;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.regex.Pattern;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

/**
 * 
 *
 */
public class App 
{
	static Pattern pipePattern = Pattern.compile("\\|");
	
	
	static final String DATABASE_URL = "database.url";
	static final String DATABASE_USERNAME = "database.username";
	static final String DATABASE_PASSWORD = "database.password";
	
	public static class CustomMapper extends Mapper<Writable, Text, Text, Text>
	{
		Text newKey = new Text();
		Text newValue = new Text();

		Connection connect;
		int taskId;
		int numOfMappers;
		
		@Override 
		public void setup(Context context) {
			taskId = context.getTaskAttemptID().getTaskID().getId();
			numOfMappers = context.getConfiguration().getInt("mapred.map.tasks", 1);
			
			if (taskId < 3 || taskId >= numOfMappers) {
				String url = context.getConfiguration().get(DATABASE_URL);
				String username = context.getConfiguration().get(DATABASE_USERNAME);
				String password = context.getConfiguration().get(DATABASE_PASSWORD);
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			      // Setup the connection with the DB
			    try {
					connect = DriverManager.getConnection(url, username, password);
							
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
		
		@Override
		public void map(Writable key, Text value, Context context) throws IOException, InterruptedException
		{
			RedEmailPojo pojo = new RedEmailPojo(value.toString());
			
			newKey.set(pojo.getEmailX() + "|Z");
			
			context.write(newKey, newValue);
			
			//queue database if needed
			if (taskId == 1 || taskId >= numOfMappers) {
				processTFppEmail(context);
			} else if (taskId == 2 || taskId >= numOfMappers) {
				processRtlEmail(context);
			} else if (taskId == 3 || taskId >= numOfMappers) {
				processTCaemEmail(context);
			} 
		}
		
		private void processTFppEmail(Context context) throws IOException, InterruptedException {
			try {
				PreparedStatement p = connect.prepareStatement("SELECT EMAIL_ADDR FROM TTNDBO.T_FPP_EMAIL");
				ResultSet rs = p.executeQuery();
				while(rs.next()) {
					String email = rs.getString(1);
					newKey.set(email + "|A");
					newValue.set("TFppEmail");
					context.write(newKey, newValue);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		private void processRtlEmail(Context context) throws IOException, InterruptedException {
			try {
				PreparedStatement p = connect.prepareStatement("SELECT EMAIL_ADDR FROM RTL_EMAIL");
				ResultSet rs = p.executeQuery();
				while(rs.next()) {
					String email = rs.getString(1);
					newKey.set(email + "|A");
					newValue.set("RtlEmail");
					context.write(newKey, newValue);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		private void processTCaemEmail(Context context) throws IOException, InterruptedException {
			try {
				PreparedStatement p = connect.prepareStatement("SELECT EMAIL_ADDR FROM T_CAEM_EMAIL");
				ResultSet rs = p.executeQuery();
				while(rs.next()) {
					String email = rs.getString(1);
					newKey.set(email + "|A");
					newValue.set("TCaemEmail");
					context.write(newKey, newValue);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		@Override
		public void cleanup(Context context) {
			if (connect != null) {
				try {
					connect.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	public static class CustomReducer extends Reducer<Text, Text, NullWritable, Text>
	{
		Text newValue = new Text();		
		
		String lagEmail = "";
		HashSet<String> matches = new HashSet<String>();
		
		
		
		@Override
		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException
		{
			String[] keySplit = pipePattern.split(key.toString());
			
			if (keySplit[0].equals(lagEmail) == false) {
				lagEmail = keySplit[0];
				matches.clear();
			}
			
			if (keySplit[1].equals("A")) {
				for (Text value: values) {
					matches.add(value.toString());
				}
			} else if (keySplit[1].equals("Z")) {
				for (String match: matches) {
					newValue.set(keySplit[0] + "|" + match);
					context.write(NullWritable.get(), newValue);
				}
			}
			
		}
	}

	public static class CustomPartitioner extends Partitioner<Text, Text>
	{
		@Override
		public int getPartition(Text key, Text value, int numPartitions)
		{
			if (numPartitions == 1)
			{
				return 0;
			} else
			{
				String keyString = pipePattern.split(key.toString())[0]; 
				
				int result = (keyString).hashCode() % numPartitions;

				//return absolute value in case hash returns a negative value
				return Math.abs(result);
			}
		}

	}
	
	public static void main(String[] args) throws Exception
	{
		if (args.length != 3)
		{
			System.out.println("exRedEmail <inputPath> <db_url> <db_username> <db_password> <outputPath> <# reducers>");
			System.out.println();
			System.out.println("Example: exRedEmail redEmail host username password results 2");
			return;
		}

		//Get values from args
		String inputPath = args[0];
		String url = args[1];
		String username = args[2];
		String password = args[3];
		String outputPath = args[4];
		String numberOfReducers = args[5];
		
		//Create job
		Job job = new Job();
		job.setJarByClass(App.class);
		//Define input format and path
		job.setInputFormatClass(TextInputFormat.class);
		
		job.getConfiguration().set(DATABASE_URL, url);
		job.getConfiguration().set(DATABASE_USERNAME, username);
		job.getConfiguration().set(DATABASE_PASSWORD, password);
		
		String[] paths = inputPath.split(",");
		for (String p: paths) {
			TextInputFormat.addInputPath(job, new Path(p));
		}
		
		//Define output format and path
		job.setOutputFormatClass(TextOutputFormat.class);
		TextOutputFormat.setOutputPath(job, new Path(outputPath));
		
		// Define the mapper and reducer
		job.setMapperClass(CustomMapper.class);
		job.setReducerClass(CustomReducer.class);
		job.setPartitionerClass(CustomPartitioner.class);

		// Define the key and value format
		job.setOutputKeyClass(NullWritable.class);
		job.setOutputValueClass(Text.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);

		job.setNumReduceTasks(Integer.parseInt(numberOfReducers));

		// Exit
		job.waitForCompletion(true);
	}

}
