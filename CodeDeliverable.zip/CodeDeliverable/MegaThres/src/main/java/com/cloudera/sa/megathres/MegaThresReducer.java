package com.cloudera.sa.megathres;

import java.io.IOException;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.regex.Pattern;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.CreateFlag;
import org.apache.hadoop.fs.FileContext;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.SequenceFile;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.compress.SnappyCodec;
import org.apache.hadoop.mapreduce.Reducer;

public class MegaThresReducer  extends Reducer<Text, Text, NullWritable, Text>  {

	String alertLoc;
	int passSessionCount;
	int alertThres;
	Text newValue = new Text();
	Pattern p = Pattern.compile("\\|");
	SequenceFile.Writer writer;
	
	@Override
	public void setup(Context context) throws IOException {
		/*
		 * job.getConfiguration().set("alert.output.loc", megaThresAlertOutput);
		 * job.getConfiguration().set("alert.past.session", pastSession);
		 * job.getConfiguration().set("alert.alert.thres", alertThres);
		 */
		alertLoc = context.getConfiguration().get("alert.output.loc");
		passSessionCount = Integer.parseInt(context.getConfiguration().get("alert.past.session"));
		alertThres = Integer.parseInt(context.getConfiguration().get("alert.alert.session"));
		
		Configuration config = new Configuration();
		Path outputFilePath = new Path(alertLoc + "/alert-" + context.getTaskAttemptID().getId());
		//Created our writer
		SequenceFile.Metadata metaData = new SequenceFile.Metadata();
	
		EnumSet<CreateFlag> enumSet = EnumSet.of(CreateFlag.CREATE);
		writer = SequenceFile.createWriter( FileContext.getFileContext(), config, outputFilePath, NullWritable.class, Text.class, SequenceFile.CompressionType.BLOCK, new SnappyCodec(), metaData, enumSet);
	}
	
	@Override
	public void cleanup(Context context) throws IOException {
		writer.close();
	}
	
	@Override
	public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
		LinkedList<String> ipAddressList = new LinkedList<String>();
		LinkedList<String> clientList = new LinkedList<String>();
		HashMap<String, Counter> ipAddressCounterMap = new HashMap<String, Counter>();
		HashMap<String, Counter> clientCounterMap = new HashMap<String, Counter>();
		String lastIpAddress = "";
		String lastClient = "";
		
		String[] keySplit = p.split(key.toString());
		
		for (Text value: values) {
			//{sessionId|score|rsaDevice|rsaIp|tid|clientSys|ipAddress}
			String[] valueSplit = p.split(value.toString());
			
			ipAddressList.add(valueSplit[6]);
			lastIpAddress = valueSplit[6];
			clientList.add(valueSplit[5]);
			lastClient = valueSplit[5];
			
			while (ipAddressList.size() > passSessionCount) {
				ipAddressList.poll();
			}
			
			while (clientList.size() > passSessionCount) {
				clientList.poll();
			}
		}
		
		StringBuilder builder = new StringBuilder();
		builder.append(keySplit[0] + "|");
		builder.append(passSessionCount);
		for (String str: ipAddressList) {
			builder.append("|" + str);
			addToCounterMap(ipAddressCounterMap, str);
		}
		for (String str: clientList) {
			builder.append("|" + str);
			addToCounterMap(clientCounterMap, str);
		}
		newValue.set(builder.toString());
		
		context.write(NullWritable.get(), newValue);
		
		Counter c = clientCounterMap.get(lastClient);
		if (c != null && c.value < alertThres) {
			newValue.set("client:" + lastIpAddress);
			writer.append(NullWritable.get(), newValue);
		}
		
		c = ipAddressCounterMap.get(lastIpAddress);
		if (c != null && c.value < alertThres) {
			newValue.set("ipAlert:" + lastIpAddress);
			writer.append(NullWritable.get(), newValue);
		}
	}
	
	public void addToCounterMap(HashMap<String, Counter> counterMap, String key) {
		Counter c = counterMap.get(key);
		if (c == null) {
			c = new Counter();
			counterMap.put(key, c);
		}
		c.value++;
	}
	
	public static class Counter {
		public int value = 0;
	}

}
