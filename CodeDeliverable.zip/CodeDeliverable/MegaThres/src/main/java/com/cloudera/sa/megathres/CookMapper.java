package com.cloudera.sa.megathres;

import java.io.IOException;
import java.util.regex.Pattern;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Mapper;


public class CookMapper  extends Mapper<Writable, Text, Text, Text> {

	Text newKey = new Text();
	Text newValue = new Text();
	
	char del = 0; 
	Pattern p = Pattern.compile("" + del);
	
	static final String FORENSIC_SCORE = "FORENSIC_SCORE=";
	
	@Override
	public void map(Writable key, Text value, Context context) throws IOException, InterruptedException
	{
		String[] split = p.split(value.toString());
		
		if (split.length == 14) {
			//This is a rsa record
			/*
				String valOutput = path.getName() + del + 
						           p.getTimestamp() + del +
						           p.getSessionKey() + del +
						           p.getRsaSessionKey() + del +
						           p.getUser_id() + del +
						           p.getOrg() + del +
						           p.getDevice_id() + del +
						           p.getIp() + del +
						           p.getHashed_ip() + del +
						           p.getEvent_type() + del +
						           p.getEvent_id() + del +
						           p.getTransaction_id() + del +
						           p.getTransaction_type() + del +
						           p.getKey_val_sets();
			 */
			if (split[2].length() > 2) {
				newKey.set(split[2]);
				
				String keyValSets = split[13];
				int idx = keyValSets.indexOf(FORENSIC_SCORE);
				if (idx > 0) {
					int endIdx = keyValSets.indexOf("&", idx);
					if (endIdx == -1) {
						endIdx = keyValSets.indexOf("]", idx);
					}
	
					if (endIdx > 0) {
					
						//{score}
						try{
							newValue.set( keyValSets.substring(idx + FORENSIC_SCORE.length(), endIdx));
						} catch (Exception e)
						{
							throw new RuntimeException (idx + "|" + endIdx + "|" + FORENSIC_SCORE.length() + "|" + (idx + FORENSIC_SCORE.length()) + "|" + keyValSets, e);
						}
						
						//Key is the session and the value is the score
						context.write(newKey, newValue );
						context.getCounter("Mapper", "Had Score").increment(1);
					} else {
						context.getCounter("Mapper", "No Score").increment(1);
					}
						
				}
			} else {
				context.getCounter("Mapper", "RSA no session key").increment(1);
			}
			
		} else if (split.length > 14){
			//This is a auth record
			/*
			 * 				String valOutput = path.getName() + del + 
						           p.getTimestamp() + del +
								   p.getMsg1() + del +
						           p.getRequestId() + del +
						           p.gettId() + del +
						           p.getmId() + del + 5
						           p.getMmId() + del +
						           p.getGrantor() + del + 
						           p.getRole() + del +
						           p.getMsg2() + del +
						           p.getMsg3() + del + 
						           p.getMsg4() + del + 
						           p.getMsg5() + del + 
						           p.getPhase() + del +
						           p.getUserId() + del +
						           p.getMethod() + del +
						           p.getUnixTimeStamp() + del +
						           p.getUnixDate() + del +
						           p.getStatus() + del +
						           p.getSessionId() + del + 19
						           p.getIpAddress() + del + 20
						           p.getRefer() + del +
						           p.getClientSys() + del +
						           p.getGateway1() + del +
						           p.getGateway2() + del +
						           p.getCustomerType() + del +
						           p.getMethodState() + del +
						           p.getMsg6() + del +
						           p.getUrl() + del +
						           p.getMsg7();
			 */
			if (split[19].length() > 2) {
				newKey.set(split[19]);
				//{mid|tid|unixtimeStamp|ipAddress|clientSys|msg6|grantor}
				newValue.set( split[5] + "|" + split[6] + "|" + split[17] + "|" + split[20] + "|" + split[22] + "|" + split[27] + "|" + split[7] + "|");
				context.write(newKey, newValue);
				context.getCounter("Mapper", "Auth with session key").increment(1);
			} else {
				context.getCounter("Mapper", "Auth no session key").increment(1);
			}
			
		} else {
			context.getCounter("Mapper", "Unknown record-" + split.length).increment(1);
		}
	}

}
