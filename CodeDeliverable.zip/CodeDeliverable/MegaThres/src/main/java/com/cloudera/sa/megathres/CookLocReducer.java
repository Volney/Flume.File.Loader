package com.cloudera.sa.megathres;

import java.io.IOException;
import java.util.regex.Pattern;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class CookLocReducer extends Reducer<Text, Text, NullWritable, Text>  {
	
	String currentLocalData = "";

	public static Pattern p = Pattern.compile("\\|");
	Text newValue = new Text();
	
	@Override
	public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
		String type = key.toString().substring(15, 16); //get sort key "123.123.123.123A" will return A
		
		if (type.equals("A")) {
			//new start ip
			for (Text value: values) {
				currentLocalData = value.toString();	
			}
			context.getCounter("Reducer", "local starts").increment(1);
		} else if (type.equals("B")) {
			//we have a cook ip
			processSessionJoin(key, values, context, currentLocalData); 
		} else if (type.equals("Z")) {
			//we have a end ip
			currentLocalData = "";	
			context.getCounter("Reducer", "local ends").increment(1);
		}
		
	}
	
	private void processSessionJoin(Text key, Iterable<Text> values, Context context, String currentLocalData) throws IOException, InterruptedException{
		String score = "";
		String tid= "";
		String mid = "";
		String unixTimeStamp= "";
		String clientSys= "";
		String grantor = "";
		String ipAddress= "";
		String rsaEnroll = "|";
		String rsaChallenge = "|";
		String rsaComplete = "|";
		String rsaDeny = "|";
		
		int counter = 0;
		
		//{score|device|Ip}
		//{mid|tid|unixtimeStamp|ipAddress|clientSys}
		for (Text value: values) {
			
			if (counter++ == 1000) {
				System.out.println("I am a bad key: " + key.toString());
			}
				
			
			String[] split = p.split(value.toString());
			if (split.length == 1) {
				//Then RSA
				score = split[0];
				context.getCounter("Reducer", "RSA:RSA").increment(1);
			} else {
				//Then Auth
				//{mid|tid|unixtimeStamp|ipAddress|clientSys|msg6|grantor}
				if (split[5].trim().length() > 2) {
					String rsaStr = split[5];
					String timeStamp = split[2];
					if (rsaStr.contains("ENROLL")) {
						rsaEnroll = rsaStr + "|" + timeStamp;
						context.getCounter("Reducer", "RSA:ENROLL").increment(1);
					} else if (rsaStr.contains("CHALLENGE")) {
						rsaChallenge = rsaStr + "|" + timeStamp;
						context.getCounter("Reducer", "RSA:CHALLENGE").increment(1);
					} else if (rsaStr.contains("COMPLETE") || rsaStr.contains("ALLOW")) {
						context.getCounter("Reducer", "RSA:COMPLETE").increment(1);
						rsaComplete = rsaStr + "|" + timeStamp;
					} else if (rsaStr.contains("DENY")) {
						context.getCounter("Reducer", "RSA:DENY").increment(1);
						rsaDeny = rsaStr + "|" + timeStamp;
					}
					
				} else {
					//If no RSA then populate core values
					context.getCounter("Reducer", "RSA:None").increment(1);
					mid = split[0];
					tid = split[1];
					unixTimeStamp = split[2];
					ipAddress = split[3];
					clientSys = split[4];	
					if (split.length == 7) {
						grantor = split[6];
					} else {
						context.getCounter("Reducer", "Auth Length " + split.length).increment(1);
					}
				}
				
			}	
		}
		
		newValue.set(key.toString().substring(1) + "|" + 
				score + "|" + 
				mid + "|" + 
				tid + "|" + 
				unixTimeStamp + "|" + 
				clientSys + "|" + 
				grantor + "|" + 
				rsaEnroll + "|" + 
				rsaChallenge + "|" + 
				rsaComplete + "|" + 
				rsaDeny + "|" + currentLocalData);
		//{sessionId|score|rsaDevice|rsaIp|mid|tid|unixTimeStamp|clientSys|ipAddress}
		context.write(NullWritable.get(), newValue);
	}

}
