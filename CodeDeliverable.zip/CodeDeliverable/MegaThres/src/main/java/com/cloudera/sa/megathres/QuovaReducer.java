package com.cloudera.sa.megathres;

import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class QuovaReducer  extends Reducer<Text, Text, NullWritable, Text>  {
	
	String currentLocalIp = "";
	String currentLocalData = "";

	Text newValue = new Text();
	
	@Override
	public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
		String ipAddress = key.toString().substring(1); //remvoe sort key "A123.123.123.123" will return 123.123.123.123
		String type = key.toString().substring(0, 1); //get sort key "A123.123.123.123" will return A
		
		if (type.equals("A")) {
			//new start ip
			currentLocalIp = ipAddress;
			for (Text value: values) {
				currentLocalData = value.toString();	
			}
			context.getCounter("Reducer", "local starts").increment(1);
		} else if (type.equals("B")) {
			//we have a cook ip
			for (Text value: values) {
				newValue.set(value.toString() + "|" + currentLocalData);
				context.write(NullWritable.get(), newValue);
				
				if (currentLocalData.isEmpty()) {
					context.getCounter("Reducer", "No local match").increment(1);
				}
					
			}
		} else if (type.equals("Z")) {
			//we have a end ip
			currentLocalIp = "";
			currentLocalData = "";	
			context.getCounter("Reducer", "local ends").increment(1);
		}
		
	}
	

}
