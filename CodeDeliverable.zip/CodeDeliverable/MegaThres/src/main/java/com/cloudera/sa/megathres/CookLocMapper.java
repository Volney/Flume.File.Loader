package com.cloudera.sa.megathres;

import java.io.IOException;
import java.util.regex.Pattern;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

public class CookLocMapper   extends Mapper<Writable, Text, Text, Text> {

	Text newKey = new Text();
	Text newValue = new Text();
	
	char del = 0; 
	Pattern nullPattern = Pattern.compile("" + del);
	Pattern pipePattern = Pattern.compile("\\|");
	
	static final String FORENSIC_SCORE = "FORENSIC_SCORE=";
	
	@Override
	public void map(Writable key, Text value, Context context) throws IOException, InterruptedException
	{
		String[] split = nullPattern.split(value.toString());
		
		if (split.length == 14) {
			//This is a rsa record
			/*
				String valOutput = path.getName() + del + 
						           p.getTimestamp() + del +
						           p.getSessionKey() + del +
						           p.getRsaSessionKey() + del +
						           p.getUser_id() + del +
						           p.getOrg() + del +
						           p.getDevice_id() + del +
						           p.getIp() + del + 7
						           p.getHashed_ip() + del +
						           p.getEvent_type() + del +
						           p.getEvent_id() + del +
						           p.getTransaction_id() + del +
						           p.getTransaction_type() + del +
						           p.getKey_val_sets();
			 */
			if (split[2].length() > 2 && split[7].length() > 2) {
				newKey.set(prepIpAddress(split[7]) + "B|" + split[2]);
				
				String keyValSets = split[13];
				int idx = keyValSets.indexOf(FORENSIC_SCORE);
				if (idx > 0) {
					int endIdx = keyValSets.indexOf("&", idx);
					if (endIdx == -1) {
						endIdx = keyValSets.indexOf("]", idx);
					}
	
					if (endIdx > 0) {
					
						//{score}
						try{
							newValue.set( keyValSets.substring(idx + FORENSIC_SCORE.length(), endIdx));
						} catch (Exception e)
						{
							throw new RuntimeException (idx + "|" + endIdx + "|" + FORENSIC_SCORE.length() + "|" + (idx + FORENSIC_SCORE.length()) + "|" + keyValSets, e);
						}
						
						//Key is the session and the value is the score
						context.write(newKey, newValue );
						context.getCounter("Mapper", "Had Score").increment(1);
					} else {
						context.getCounter("Mapper", "No Score").increment(1);
					}
						
				}
			} else {
				context.getCounter("Mapper", "RSA no session key").increment(1);
			}
			
		} else if (split.length == 30){
			//This is a auth record
			/*
			 * 				String valOutput = path.getName() + del + 
						           p.getTimestamp() + del +
								   p.getMsg1() + del +
						           p.getRequestId() + del +
						           p.gettId() + del +
						           p.getmId() + del + 5
						           p.getMmId() + del +
						           p.getGrantor() + del + 
						           p.getRole() + del +
						           p.getMsg2() + del +
						           p.getMsg3() + del + 
						           p.getMsg4() + del + 
						           p.getMsg5() + del + 
						           p.getPhase() + del +
						           p.getUserId() + del +
						           p.getMethod() + del +
						           p.getUnixTimeStamp() + del +
						           p.getUnixDate() + del +
						           p.getStatus() + del +
						           p.getSessionId() + del + 19
						           p.getIpAddress() + del + 20
						           p.getRefer() + del +
						           p.getClientSys() + del +
						           p.getGateway1() + del +
						           p.getGateway2() + del +
						           p.getCustomerType() + del +
						           p.getMethodState() + del +
						           p.getMsg6() + del +
						           p.getUrl() + del +
						           p.getMsg7();
			 */
			if (split[20].length() > 2 && split[19].length() > 2) {
				newKey.set("B" + prepIpAddress(split[20]) + "|" + split[19]);
				//{mid|tid|unixtimeStamp|ipAddress|clientSys|msg6|grantor}
				newValue.set( split[5] + "|" + split[6] + "|" + split[17] + "|" + split[20] + "|" + split[22] + "|" + split[27] + "|" + split[7] + "|");
				context.write(newKey, newValue);
				context.getCounter("Mapper", "Auth with session key").increment(1);
			} else {
				context.getCounter("Mapper", "Auth no session key").increment(1);
			}
			
		} else  {
			//We have a quova
			split = pipePattern.split(value.toString());
			
			if (split[2].length() > 2) {
				
				//75677696|75678463|"4.130.192.0"|"4.130.194.255"|"north america"|99|"united states"|99|"us"|"south central"|96|"texas"|94|"houston"|90|"713"|"77001"|618|92|26420|92|3360|92|-6.00000000000000E+000|+2.97630000000000E+001|-9.53830000000000E+001|"dialup"|"pop"|"low"|"N"|"level3"|"net"|3356|"level 3 communications"|"level 3 communications  inc."|20080527|45909265|7|7
				newKey.set(prepIpAddress(split[2]) + "A");
				newValue.set(split[24] + "|" + split[25] + "|" + split[36]);
				context.write(newKey, newValue);
				
				newKey.set(prepIpAddress(split[3]) + "Z");
				context.write(newKey, newValue);
			}
		}
	}

	Pattern ipP = Pattern.compile("\\.");
	
	public String prepIpAddress(String ip) {
		//4.130.192.0 004.130.192.000
		try {
			String[] ipPart = ipP.split(ip);
			StringBuilder builder = new StringBuilder();
			for (int i = 0; i < ipPart.length; i++) {
				builder.append(String.format("%03d", Integer.parseInt(ipPart[i])));
				if (i < ipPart.length -1){
					builder.append(".");
				}
				
			}
			return builder.toString();
		} catch (Exception e) {
			//do nothing
		}
			
		return "000.000.000.000";
	}
}
