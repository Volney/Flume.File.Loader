package com.cloudera.sa.megathres;

import java.io.IOException;
import java.util.regex.Pattern;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Mapper;

public class MegaThresMapper  extends Mapper<Writable, Text, Text, Text> {

	//{sessionId|score|rsaDevice|rsaIp|tid|unixTimeStamp|clientSys|ipAddress}
	Text newKey = new Text();
	Text newValue = new Text();
	
	char del = 0; 
	Pattern p = Pattern.compile("\\|");
	
	
	@Override
	public void map(Writable key, Text value, Context context) throws IOException, InterruptedException
	{
		
		String[] split = p.split(value.toString());
		
		if (split.length == 8) {
			//This is enriched data
			
			//{sessionId|score|rsaDevice|rsaIp|mid|tid|unixTimeStamp|clientSys|ipAddress}
			if (split[4].isEmpty() == false) {
				newKey.set(split[4] + "|" + split[6]);
				
				//{sessionId|score|rsaDevice|rsaIp|tid|clientSys|ipAddress}
				newValue.set(split[0] + "|" + 
						split[1] + "|" + 
						split[2] + "|" + 
						split[3] + "|" + 
						split[5] + "|" +
						split[7] + "|" + 
						split[8]  
						);
				context.write(newKey, newValue);	
			}
			
		} else {
			//This is megaThresSum data 
			//Out of scope for the SoW
		}
			
			
	}

}
