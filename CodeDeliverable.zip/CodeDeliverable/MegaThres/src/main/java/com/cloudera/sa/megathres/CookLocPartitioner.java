package com.cloudera.sa.megathres;

import java.util.regex.Pattern;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class CookLocPartitioner  extends Partitioner<Text, Text> {

	Pattern p = Pattern.compile("\\.");
	
	@Override
	public int getPartition(Text key, Text value, int numPartitions)
	{
		if (numPartitions == 1)
		{
			return 0;
		} else
		{
			String keyString = p.split(key.toString().substring(0,15))[0]; 
			
			//If keyString ends in A then it is a page
			int result = (keyString).hashCode() % numPartitions;

			//return absolute value in case hash returns a negative value
			return Math.abs(result);
		}
	}


}
