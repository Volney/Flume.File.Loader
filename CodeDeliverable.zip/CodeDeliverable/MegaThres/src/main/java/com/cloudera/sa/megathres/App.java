package com.cloudera.sa.megathres;

import java.io.IOException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.SequenceFileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;

public class App 
{

	public static void main(String[] args) throws Exception
	{
		if (args.length < 4)
		{
			System.out.println("0");
			System.out.println("MegaThres <cook> <rsaInput> <authInput> <cookOutput> <numOfReducers>");
			System.out.println("MegaThres <quova> <cookInput> <quovaInput> <output> <numOfReducers>");
			System.out.println("MegaThres <cookloc> <rsaInput> <authInput> <quova> <cookOutput> <numOfReducers>");
			System.out.println("MegaThres <thres> <cookInput> <megaThresSumOutput> <megaThresAlertOutput> < # reducers> <pastSession> <alertThres>");
			System.out.println();
			System.out.println("Example: MegaThres auth rsa geo 1");
			return;
		}

		//Get values from args
		String jobKey = args[0];
		if (jobKey.equals("cook") && args.length == 5) {
			String authPath = args[1];
			String rsaPath = args[2];
			String sessionJoinOutput = args[3];	
			String numOfReducers = args[4];
				
			Job job = cookJob(authPath, rsaPath, sessionJoinOutput, numOfReducers);
			// Exit
			job.waitForCompletion(true);	
		} else if (jobKey.equals("thres")) {
//			megaThresJob(String enrichAuthOutput, String megaThresSumInput, String megaThresSumOutput, 
	//				String megaThresAlertOutput, pastSession, alertThres, numOfReducers)
		} else if (jobKey.equals("quova")) {
			String cookInput = args[1];
			String quovaInput = args[2];
			String output = args[3];	
			String numOfReducers = args[4];
				
			Job job = quovaJob(cookInput, quovaInput, output, numOfReducers);
			// Exit
			job.waitForCompletion(true);
		} else if (jobKey.equals("cookloc")) {
			String authPath = args[1];
			String rsaPath = args[2];
			String quovaInput = args[3];
			String output = args[4];	
			String numOfReducers = args[5];
				
			Job job = cookLocJob(authPath, rsaPath, quovaInput, output, numOfReducers);
			// Exit
			job.waitForCompletion(true);
		}else {
            System.out.println("1-" + jobKey + " " + args.length);
            System.out.println("MegaThres <cook> <rsaInput> <authInput> <cookOutput> <numOfReducers>");
			System.out.println("MegaThres <quova> <cookInput> <quovaInput> <output> <numOfReducers>");
			System.out.println("MegaThres <cookloc> <rsaInput> <authInput> <quova> <cookOutput> <numOfReducers>");
			System.out.println("MegaThres <thres> <cookInput> <megaThresSumOutput> <megaThresAlertOutput> < # reducers> <pastSession> <alertThres>");
			System.out.println();
			System.out.println("Example: MegaThres auth rsa geo 1");
			return;
		}
		
		
	}

	private static Job cookLocJob(String authPath, String rsaPath, String quovaInput, String output, String numOfReducers) throws IOException {
		//Create job
		Job job = new Job();
		job.setJarByClass(App.class);
		//Define input format and path
		job.setInputFormatClass(SequenceFileInputFormat.class);
		SequenceFileInputFormat.addInputPath(job, new Path(authPath));
		SequenceFileInputFormat.addInputPath(job, new Path(rsaPath));
		SequenceFileInputFormat.addInputPath(job, new Path(quovaInput));
		
		//Define output format and path
		job.setOutputFormatClass(SequenceFileOutputFormat.class);
		SequenceFileOutputFormat.setOutputPath(job, new Path(output));
		
		// Define the mapper and reducer
		job.setMapperClass(CookLocMapper.class);
		job.setReducerClass(CookLocReducer.class);
		job.setPartitionerClass(CookLocPartitioner.class);

		// Define the key and value format
		job.setOutputKeyClass(NullWritable.class);
		job.setOutputValueClass(Text.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);

		job.setNumReduceTasks(Integer.parseInt(numOfReducers));
		return job;
		
	}

	
	private static Job megaThresJob(String enrichAuthOutput, String megaThresSumInput, String megaThresSumOutput, 
			String megaThresAlertOutput, String pastSession, String alertThres,
			String numOfReducers) throws IOException {
		//Create job
		Job job = new Job();
		
		job.getConfiguration().set("alert.output.loc", megaThresAlertOutput);
		job.getConfiguration().set("alert.past.session", pastSession);
		job.getConfiguration().set("alert.alert.thres", alertThres);
		
		job.setJarByClass(App.class);
		//Define input format and path
		job.setInputFormatClass(SequenceFileInputFormat.class);
		SequenceFileInputFormat.addInputPath(job, new Path(enrichAuthOutput));
		SequenceFileInputFormat.addInputPath(job, new Path(megaThresSumInput));
		
		//Define output format and path
		job.setOutputFormatClass(SequenceFileOutputFormat.class);
		SequenceFileOutputFormat.setOutputPath(job, new Path(megaThresSumOutput));
		
		// Define the mapper and reducer
		job.setMapperClass(CookMapper.class);
		job.setReducerClass(CookReducer.class);
		job.setPartitionerClass(MegaThresPartitioner.class);

		// Define the key and value format
		job.setOutputKeyClass(NullWritable.class);
		job.setOutputValueClass(Text.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);

		job.setNumReduceTasks(Integer.parseInt(numOfReducers));
		return job;
	}
	
	private static Job quovaJob(String cookInput, String quovaInput, String output, String numOfReducers) throws IOException {
		//Create job
		Job job = new Job();
		job.setJarByClass(App.class);
		//Define input format and path
		job.setInputFormatClass(SequenceFileInputFormat.class);
		SequenceFileInputFormat.addInputPath(job, new Path(cookInput));
		SequenceFileInputFormat.addInputPath(job, new Path(quovaInput));
		
		//Define output format and path
		job.setOutputFormatClass(SequenceFileOutputFormat.class);
		SequenceFileOutputFormat.setOutputPath(job, new Path(output));
		
		// Define the mapper and reducer
		job.setMapperClass(QuovaMapper.class);
		job.setReducerClass(QuovaReducer.class);
		job.setPartitionerClass(QuovaPartitioner.class);

		// Define the key and value format
		job.setOutputKeyClass(NullWritable.class);
		job.setOutputValueClass(Text.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);

		job.setNumReduceTasks(Integer.parseInt(numOfReducers));
		return job;
		
	}
	
	private static Job cookJob(String authPath, String rsaPath, String sessionJoinPath,
			String numOfReducers) throws IOException {
		//Create job
		Job job = new Job();
		job.setJarByClass(App.class);
		//Define input format and path
		job.setInputFormatClass(SequenceFileInputFormat.class);
		SequenceFileInputFormat.addInputPath(job, new Path(authPath));
		SequenceFileInputFormat.addInputPath(job, new Path(rsaPath));
		
		//Define output format and path
		job.setOutputFormatClass(SequenceFileOutputFormat.class);
		SequenceFileOutputFormat.setOutputPath(job, new Path(sessionJoinPath));
		
		// Define the mapper and reducer
		job.setMapperClass(CookMapper.class);
		job.setReducerClass(CookReducer.class);

		// Define the key and value format
		job.setOutputKeyClass(NullWritable.class);
		job.setOutputValueClass(Text.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);

		job.setNumReduceTasks(Integer.parseInt(numOfReducers));
		return job;
	}

}
