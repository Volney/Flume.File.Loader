package com.cloudera.sa.megathres;

import java.io.IOException;
import java.util.regex.Pattern;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Mapper;



public class QuovaMapper  extends Mapper<Writable, Text, Text, Text> {

	Pattern p = Pattern.compile("\\|");
	Text newKey = new Text();
	Text newValue = new Text();
	
	@Override
	public void map(Writable key, Text value, Context context) throws IOException, InterruptedException {
		String[] split = p.split(value.toString());
		if (split.length == 18) {
			//We have a quova
			
			
			
			//75677696|75678463|"4.130.192.0"|"4.130.194.255"|"north america"|99|"united states"|99|"us"|"south central"|96|"texas"|94|"houston"|90|"713"|"77001"|618|92|26420|92|3360|92|-6.00000000000000E+000|+2.97630000000000E+001|-9.53830000000000E+001|"dialup"|"pop"|"low"|"N"|"level3"|"net"|3356|"level 3 communications"|"level 3 communications  inc."|20080527|45909265|7|7
			newKey.set("A" + prepIpAddress(split[2]));
			newValue.set(split[24] + "|" + split[25] + "|" + split[36]);
			context.write(newKey, newValue);
			
			newKey.set("Z" + split[3]);
			context.write(newKey, newValue);
		} else {
			/*
			 * key.toString() + "|" + 
				score + "|" + 
				mid + "|" + 
				tid + "|" + 
				unixTimeStamp + "|" + 
				clientSys + "|" + 
				ipAddress + "|" + 
				grantor + "|" + 
				rsaEnroll + "|" + 
				rsaChallenge + "|" + 
				rsaComplete + "|" + 
				rsaDeny
			 */
			newKey.set("B" + prepIpAddress(split[6]));
			
			context.write(newKey, value);
		}
			
	}
	
	Pattern ipP = Pattern.compile("\\.");
	
	public String prepIpAddress(String ip) {
		//4.130.192.0 004.130.192.000
		
		String[] ipPart = ipP.split(ip);
		StringBuilder builder = new StringBuilder();
		for (int i = 0; i < ipPart.length; i++) {
			builder.append(String.format("%03d", Integer.parseInt(ipPart[i])));
			if (i < ipPart.length -1){
				builder.append(".");
			}
		}
			
		return builder.toString();
	}
	

}
