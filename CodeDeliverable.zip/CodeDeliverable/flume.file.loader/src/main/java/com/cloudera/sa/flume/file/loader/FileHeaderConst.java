package com.cloudera.sa.flume.file.loader;

public class FileHeaderConst {

  public static final String FILENAME = "fn";
  public static final String BYTE_OFF_SITE = "bos";
  public static final String RECORD_NUM = "rn";
  public static final String YEAR_MONTH = "yearMonth";

}
