package com.cloudera.sa.flume.hbase.filter;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;


public class HBaseDataLoader {

	public static void main(String[] args) throws IOException {
		
		Configuration config = HBaseConfiguration.create();
		HTable flagKeyTable = new HTable(config, "FLAG_KEYS");
		
		ArrayList<Put> putList = new ArrayList<Put>();
		
		for (int i = 0; i < 100; i++) {
			
			String value =  Integer.toHexString((int)(Math.random() * 500)); // why hex? just to have something other then a number 
			Put put = new Put(Bytes.toBytes(value));
			put.add(Bytes.toBytes("cf"), Bytes.toBytes("X"), Bytes.toBytes(i));
			putList.add(put);
		}
		
		flagKeyTable.put(putList);
	}

}
