package com.cloudera.sa.flume.hbase.filter;

import org.apache.flume.ChannelException;
import org.apache.flume.Event;
import org.apache.flume.EventDeliveryException;
import org.apache.flume.PollableSource;
import org.apache.flume.event.EventBuilder;
import org.apache.flume.source.AbstractSource;
import org.apache.hadoop.hbase.util.Bytes;

public class TestDataSource extends AbstractSource implements PollableSource {

  @Override 
  public Status process() throws EventDeliveryException {
    try {
      
      String value =  Integer.toHexString((int)(Math.random() * 500));
      Event event = EventBuilder.withBody(Bytes.toBytes(value));
      getChannelProcessor().processEvent(event);
    } catch (ChannelException ex) {
      return Status.BACKOFF;
    }
    return Status.READY;
  }
  
  
  @Override
  public void start() {
    System.out.println("TestDataSource starting");

    super.start();

    System.out.println("TestDataSource started");
  }

  @Override
  public void stop() {
    System.out.println("TestDataSource stopping");

    super.stop();

    System.out.println("TestDataSource stopped. Metrics:{}");
  }
  
}
