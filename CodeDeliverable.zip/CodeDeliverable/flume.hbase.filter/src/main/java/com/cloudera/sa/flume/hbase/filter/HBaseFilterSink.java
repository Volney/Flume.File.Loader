package com.cloudera.sa.flume.hbase.filter;

import java.io.IOException;

import org.apache.flume.Channel;
import org.apache.flume.Event;
import org.apache.flume.EventDeliveryException;
import org.apache.flume.Transaction;
import org.apache.flume.sink.AbstractSink;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;


public class HBaseFilterSink extends AbstractSink {

  HTable flagKeyTable;
  HTable flagReportTable;
  
  @Override
  public synchronized void start() {
    super.start();
    Configuration config = HBaseConfiguration.create();
    try {
      flagKeyTable = new HTable(config, "FLAG_KEYS");
      flagReportTable = new HTable(config, "FLAG_REPORT");
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  @Override
  public synchronized void stop() {
    super.stop();
    try {
      flagKeyTable.close();
      flagReportTable.close();
    } catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    
  }
  
  public Status process() throws EventDeliveryException {

    Channel channel = getChannel();
    Transaction transaction = channel.getTransaction();
    Event event = null;

    try {
      transaction.begin();
      event = channel.take();
      transaction.commit();

      if (event != null) {
        processEvent(event);
        return Status.READY;
      } else {
        return Status.BACKOFF;
      }
    } catch (Exception ex) {
      transaction.rollback();
      throw new EventDeliveryException("Failed to deliver event: " + event, ex);
    } finally {
      transaction.close();
    }
  }

  private void processEvent(Event event) throws IOException{
    String body = Bytes.toString(event.getBody());
    Get get = new Get(Bytes.toBytes(body));
    Result r = flagKeyTable.get(get);
    if (r.getRow() != null) {
      Put put = new Put(Bytes.toBytes(body));
      put.add(Bytes.toBytes("cf"), Bytes.toBytes("Tm"), Bytes.toBytes(System.currentTimeMillis()));
      flagReportTable.put(put);
    }
  }
  
}
