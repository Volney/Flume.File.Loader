package com.cloudera.sa.example.windowing;

import java.io.IOException;
import java.util.StringTokenizer;
import java.util.regex.Pattern;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.hadoop.mapreduce.lib.input.SequenceFileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

/**
 * Stock windowing function
 * 
 * original format is 
 * ticker|Time|price
 * 
 * Time is in the following format YYYYmmddHHMMSS
 * 
 * The output will be 
 * 
 * ticker|Time|price|max|min|avg|count
 *
 */
public class App 
{
	public static class CustomMapper extends Mapper<Writable, Text, Text, Text>
	{
		Text newKey = new Text();
		Text newValue = new Text();

		@Override
		public void map(Writable key, Text value, Context context) throws IOException, InterruptedException
		{
			StringTokenizer st = new StringTokenizer(value.toString(), "|");
			String ticker = st.nextToken();
			String time = st.nextToken();
			String price = st.nextToken();
			
			newKey.set(ticker + "|" + time);
			newValue.set(price);
			
			context.write(newKey, newValue);
		}
	}

	public static class CustomReducer extends Reducer<Text, Text, NullWritable, Text>
	{
		Text newValue = new Text();		
		
		String lagTicker = "";
		Double maxPrice = Double.MIN_VALUE;
		Double minPrice = Double.MAX_VALUE;
		Double avgPrice = 0.0;
		int tradeCount = 0;
		long counter = 0;
		
		@Override
		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException
		{
			StringTokenizer st = new StringTokenizer(key.toString(), "|");
			String ticker = st.nextToken();
			String time = st.nextToken();
			
			if (ticker.equals(lagTicker) == false) {
				lagTicker = ticker;
				resetMovingValues();
			}
			
			for (Text value: values) {
				Double price = Double.parseDouble(value.toString());
				
				if (price > maxPrice) maxPrice = price;
				if (price < minPrice) minPrice = price;
				if (tradeCount == 0) avgPrice = price; 
				else avgPrice = (avgPrice * tradeCount + price)/(tradeCount + 1);
				
				tradeCount++;
				
				newValue.set(ticker + "|" + time + "|" + price + "|" + maxPrice + "|" + minPrice + "|" + avgPrice + "|" + tradeCount);
				
				context.write(NullWritable.get(), newValue);
			}
		}

		private void resetMovingValues() {
			maxPrice = Double.MIN_VALUE;
			minPrice = Double.MAX_VALUE;
			avgPrice = 0.0;
			tradeCount = 0;
		}
	}

	public static class CustomPartitioner extends Partitioner<Text, Text>
	{

		Pattern p = Pattern.compile("\\|");
		
		
		@Override
		public int getPartition(Text key, Text value, int numPartitions)
		{
			if (numPartitions == 1)
			{
				return 0;
			} else
			{
				
				String keyString = p.split(key.toString())[0]; 
				
				int result = (keyString).hashCode() % numPartitions;

				//return absolute value in case hash returns a negative value
				return Math.abs(result);
			}
		}

	}
	
	public static void main(String[] args) throws Exception
	{
		if (args.length != 3)
		{
			System.out.println("exWindow <inputPath> <outputPath> <# reducers>");
			System.out.println();
			System.out.println("Example: exWindow trades results 2");
			return;
		}

		//Get values from args
		String inputPath = args[0];
		String outputPath = args[1];
		String numberOfReducers = args[2];
		
		//Create job
		Job job = new Job();
		job.setJarByClass(App.class);
		//Define input format and path
		job.setInputFormatClass(TextInputFormat.class);
		
		String[] paths = inputPath.split(",");
		for (String p: paths) {
			TextInputFormat.addInputPath(job, new Path(p));
		}
		
		//Define output format and path
		job.setOutputFormatClass(TextOutputFormat.class);
		TextOutputFormat.setOutputPath(job, new Path(outputPath));
		
		// Define the mapper and reducer
		job.setMapperClass(CustomMapper.class);
		job.setReducerClass(CustomReducer.class);
		job.setPartitionerClass(CustomPartitioner.class);

		// Define the key and value format
		job.setOutputKeyClass(NullWritable.class);
		job.setOutputValueClass(Text.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);

		job.setNumReduceTasks(Integer.parseInt(numberOfReducers));

		// Exit
		job.waitForCompletion(true);
	}

}
