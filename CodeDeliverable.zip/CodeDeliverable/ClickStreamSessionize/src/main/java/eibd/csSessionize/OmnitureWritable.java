package eibd.csSessionize;


import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Pattern;

import org.apache.hadoop.io.Writable;


public class OmnitureWritable implements Writable, Cloneable{

	private static String PAD_DELIM = "-";
	
	private String filename = PAD_DELIM;
	private long clickDate = 0;					// col 1 
	private String Mid = PAD_DELIM;					// col 2
	private String Tid = PAD_DELIM;					// col 3
	private String requestPageStr = PAD_DELIM;			// col 4
	private String requestDynamicStr = PAD_DELIM;		// col 5
	private String referrerPageStr = PAD_DELIM;		// col 6
	private String referrerDynamicStr = PAD_DELIM;		// col 7
	private String status = PAD_DELIM;					// col 8
	private String userAgent = PAD_DELIM;				// col 9
	private String eSiteSessionKey = PAD_DELIM;		// col 10 -- pad with dash
	private String febsecSessionKey = PAD_DELIM;		// col 11
	private int sequenceNum = 0;				// col 12
	private String febsecCoAttributes = PAD_DELIM;		// col 13 -- pad with dash
	private String ipAddr = PAD_DELIM;					// col 14 
	private String mimeMid = PAD_DELIM;				// col 15
	private String relMap = PAD_DELIM;					// col 16
	private String sessionFlag = PAD_DELIM;			// col 17
	private String role = PAD_DELIM;					// col 18
	private String assocFlag = PAD_DELIM;				// col 19
	private String dwellTime = PAD_DELIM;				// col 20 -- pad with dash

	
	static Pattern tabPattern = Pattern.compile("\t");
	static Pattern pipePattern = Pattern.compile("\\|\\|");
	
	static SimpleDateFormat omniSource = new SimpleDateFormat("dd/MMM/yyyy:hh:mm:ss");
	
	/**
	 * Parses row log line, and AM separately, to decipher and populate fields.
	 * 
	 * The log line format is as follows:
	 * ---------
	 * Token -1 - filename
	 * Token 0 - client ip address $c_ip
	 * Token 1 - $ident_user
	 * Token 2 - auth user - $auth_user
	 * Token 3 - date and time stamp - $sysdate
	 * Token 4 - status (i.e. 200), $stat
	 * Token 5  - content length, $len
	 * Token 6 - referer url , $referrer
	 * Token 7 - User agent, $agent
	 * Token 8 - Request Method (i.e. GET or POST)$method
	 * Token 9 - Request URI, $uri
	 * Token 10 - Request Query - $query
	 * Token 11 - Request protocol (i.e. HTTP/1.0)
	 * Token 12 - Request duration
	 * Token 13 - User details
	 * Token 14 - Client info
	 * Token 15 - plan info
	 * Token 16 - Request ID
	 * Token 17 - client IP Address
	 * Token 18 - AM Log
	 * ---------
	 * 
	 * @param logLine - the raw log line
	 */
	public void set(String logLine) {
		
		String[] elementArray = tabPattern.split(logLine);
		
		set(elementArray);
	}
	
	public void set(String[] elementArray) {
		String[] pipeSplit = pipePattern.split(elementArray[0]);
		
		filename = pipeSplit[0];
		elementArray[0] = pipeSplit[1];
		
		// each field of the log line is an element in this array, indexed in the order in which they appear
		
		
		// parse out the date first
		String strDate = elementArray[3];
		strDate = strDate.substring(1, strDate.length()-7);  // strip the open/close brackets, and TZ info
		Date omniDate = new Date();
		
		try  { 
			
			omniDate = omniSource.parse(strDate);
		} catch(ParseException pe) { 
			System.out.println("Error creating date object: " + pe);
			return;
		}
		
		int numElements = elementArray.length;
		AM theAM = null;
		if (numElements == 18) {
			theAM = AM.parse(elementArray[17]);
		} else { 
			theAM = AM.parse(elementArray[18]);
		}

		clickDate = omniDate.getTime();
		Mid = theAM.getTheMID();  //from the AM
		Tid = theAM.getTheTID();
		
		requestPageStr = elementArray[9].replaceAll("\\\"", "");  // 10th field in raw log  FIXME - domain fileName....
		requestDynamicStr = elementArray[10].replaceAll("\\\"", ""); // 11th field in raw log -- sujit
		if (requestDynamicStr.length()==0) requestDynamicStr=PAD_DELIM;
		String referrer = elementArray[6];
		//check to see if there were GET paramaters in referrer string
		if(referrer.indexOf('?') != -1) {  // if there is a dynamic query string...
			String[] refElem = referrer.split("\\?");
			referrerPageStr = refElem[0].replaceAll("\\\"", "");
			referrerDynamicStr = refElem[1].replaceAll("\\\"", "");
			if (referrerDynamicStr.length()==0) referrerDynamicStr=PAD_DELIM;
		} else {
			referrerPageStr = referrer.replaceAll("\\\"", "");
//			referrerDynamicStr = PAD_DELIM;  already set
		}
		
		status = elementArray[4];  // 4th field in raw log
		userAgent = elementArray[7].replaceAll("\\\"", ""); // 7th field in raw log
//		eSiteSessionKey = PAD_DELIM;  already set
		febsecSessionKey = theAM.getSessionKey();
//		sequenceNum = 0;  // already set
//		febsecCoAttributes = PAD_DELIM;  already set
		ipAddr = elementArray[0];
		mimeMid = theAM.getMimedMID(); // from the AM
		relMap = theAM.getRelMap();
		sessionFlag = "0"; // FIXME ?
		role = theAM.getRole();
		assocFlag = "0"; // FIXME
//		dwellTime = PAD_DELIM;  already set
//		*/			

	}
	
	@Override
	public void readFields(DataInput in) throws IOException {
		this.clickDate = in.readLong();
		this.Mid = in.readUTF();
		this.Tid = in.readUTF();
		this.requestPageStr = in.readUTF();
		this.requestDynamicStr = in.readUTF();
		this.referrerPageStr = in.readUTF();
		this.referrerDynamicStr = in.readUTF();
		this.status = in.readUTF();
		this.userAgent = in.readUTF();
		this.eSiteSessionKey = in.readUTF();
		this.febsecSessionKey = in.readUTF();
		this.sequenceNum = in.readInt();
		this.febsecCoAttributes = in.readUTF();
		this.ipAddr = in.readUTF();
		this.mimeMid = in.readUTF();
		this.relMap = in.readUTF();
		this.sessionFlag = in.readUTF();
		this.role = in.readUTF();
		this.assocFlag = in.readUTF();
		this.dwellTime = in.readUTF();
	}

	@Override
	public void write(DataOutput out) throws IOException {
		out.writeLong(this.clickDate);
		out.writeUTF(this.Mid);
		out.writeUTF(this.Tid);
		out.writeUTF(this.requestPageStr);
		out.writeUTF(this.requestDynamicStr);
		out.writeUTF(this.referrerPageStr);
		out.writeUTF(this.referrerDynamicStr);
		out.writeUTF(this.status);
		out.writeUTF(this.userAgent);
		out.writeUTF(this.eSiteSessionKey);
		out.writeUTF(this.febsecSessionKey);
		out.writeInt(this.sequenceNum);
		out.writeUTF(this.febsecCoAttributes);
		out.writeUTF(this.ipAddr);
		out.writeUTF(this.mimeMid);
		out.writeUTF(this.relMap);
		out.writeUTF(this.sessionFlag);
		out.writeUTF(this.role);
		out.writeUTF(this.assocFlag);
		out.writeUTF(this.dwellTime);
			
	}

	public long getClickDate() {
		return clickDate;
	}

	public void setClickDate(long clickDate) {
		this.clickDate = clickDate;
	}

	public String getMid() {
		return Mid;
	}

	public void setMid(String mid) {
		this.Mid = mid;
	}

	public String getTid() {
		return Tid;
	}

	public void setTid(String tid) {
		this.Tid = tid;
	}

	public String getRequestPageStr() {
		return requestPageStr;
	}

	public void setRequestPageStr(String requestPageStr) {
		// #FIXME
		this.requestPageStr = requestPageStr;
	}

	public String getRequestDynamicStr() {
		return requestDynamicStr;
	}

	public void setRequestDynamicStr(String requestDynamicStr) {
		this.requestDynamicStr = requestDynamicStr;
	}

	public String getReferrerPageStr() {
		return referrerPageStr;
	}

	public void setReferrerPageStr(String referrerPageStr) {
		this.referrerPageStr = referrerPageStr;
	}

	public String getReferrerDynamicStr() {
		return referrerDynamicStr;
	}

	public void setReferrerDynamicStr(String referrerDynamicStr) {
		this.referrerDynamicStr = referrerDynamicStr;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUserAgent() {
		return userAgent;
	}

	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}

	public String geteSiteSessionKey() {
		return eSiteSessionKey;
	}

	public void seteSiteSessionKey(String eSiteSessionKey) {
		this.eSiteSessionKey = eSiteSessionKey;
	}

	public String getFebsecSessionKey() {
		return febsecSessionKey;
	}

	public void setFebsecSessionKey(String febsecSessionKey) {
		this.febsecSessionKey = febsecSessionKey;
	}

	public int getSequenceNum() {
		return sequenceNum;
	}

	public void setSequenceNum(int sequenceNum) {
		this.sequenceNum = sequenceNum;
	}

	public String getFebsecCoAttributes() {
		return febsecCoAttributes;
	}

	public void setFebsecCoAttributes(String febsecCoAttributes) {
		this.febsecCoAttributes = febsecCoAttributes;
	}

	public String getIpAddr() {
		return ipAddr;
	}

	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}

	public String getMimedMid() {
		return mimeMid;
	}

	public void setMimedMid(String mimedMid) {
		this.mimeMid = mimedMid;
	}

	public String getRelMap() {
		return relMap;
	}

	public void setRelMap(String relMap) {
		this.relMap = relMap;
	}

	public String getAssocFlag() {
		return assocFlag;
	}

	public void setAssocFlag(String assocFlag) {
		this.assocFlag = assocFlag;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getSessionFlag() {
		return sessionFlag;
	}

	public void setSessionFlag(String sessionFlag) {
		this.sessionFlag = sessionFlag;
	}

	public String getDwellTime() {
		return dwellTime;
	}

	public void setDwellTime(String dwellTime) {
		this.dwellTime = dwellTime;
	}

	@Override
	public String toString() {
		return filename
				+ "\t" + clickDate  
				+ "\t" + Mid
				+ "\t" + Tid 
				+ "\t" + requestPageStr
				+ "\t" + requestDynamicStr
				+ "\t" + referrerPageStr
				+ "\t" + referrerDynamicStr 
				+ "\t" + status
				+ "\t" + userAgent
				+ "\t" + eSiteSessionKey
				+ "\t" + febsecSessionKey
				+ "\t" + sequenceNum
				+ "\t" + febsecCoAttributes 
				+ "\t" + ipAddr
				+ "\t" + mimeMid
				+ "\t" + relMap
				+ "\t" + sessionFlag
				+ "\t" + role
				+ "\t" + assocFlag
				+ "\t" + dwellTime;
		}
	
	public void fromStringArray(String [] tokens){
		
		this.clickDate = new Long(tokens[0]).longValue();
		this.Mid = tokens[1];
		this.Tid = tokens[2];
		this.requestPageStr = tokens[3];
		this.requestDynamicStr = tokens[4];
		this.referrerPageStr = tokens[5];
		this.referrerDynamicStr = tokens[6];
		this.status = tokens[7];
		this.userAgent = tokens[8];
		this.eSiteSessionKey = tokens[9];
		this.febsecSessionKey = tokens[10];
		this.sequenceNum = new Integer(tokens[11]).intValue();
		this.febsecCoAttributes = tokens[12];
		this.ipAddr = tokens[13];
		this.mimeMid = tokens[14];
		this.relMap = tokens[15];
		this.sessionFlag = tokens[16];
		this.role = tokens[17];
		this.assocFlag = tokens[18];
		this.dwellTime = tokens[19];
		
	}

	@Override
	public OmnitureWritable clone(){
		try {
			return (OmnitureWritable)super.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		return null;
	}

}
