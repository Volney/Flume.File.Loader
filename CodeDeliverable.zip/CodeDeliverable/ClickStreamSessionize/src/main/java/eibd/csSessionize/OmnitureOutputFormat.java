package eibd.csSessionize;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileAlreadyExistsException;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.InvalidJobConfException;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.RecordWriter;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.TextOutputFormat;
import org.apache.hadoop.util.Progressable;

public class OmnitureOutputFormat<K, V> extends FileOutputFormat<K, V> {

	protected TextOutputFormat<NullWritable, Text> containedWriter;
	protected RecordWriter<K, V> recordWriter;
	
	public OmnitureOutputFormat() {
		containedWriter = new TextOutputFormat<NullWritable, Text>();
	}

	@Override
	public RecordWriter<K, V> getRecordWriter(FileSystem arg0, JobConf arg1,
			String arg2, Progressable arg3) throws IOException {
		if (this.recordWriter == null){
			this.recordWriter = new OmnitureRecordWriter(this.containedWriter.getRecordWriter(arg0, arg1, arg2, arg3));
		}
		return recordWriter;
	}
	
	@Override
	public void checkOutputSpecs(FileSystem arg0, JobConf arg1)
			throws FileAlreadyExistsException, InvalidJobConfException,
			IOException {
		super.checkOutputSpecs(arg0, arg1);
		this.containedWriter.checkOutputSpecs(arg0, arg1);
	}
	
	public TextOutputFormat<NullWritable, Text> getContainedWriter() {
		return containedWriter;
	}
	
	public static class OmnitureRecordWriter implements RecordWriter{
		
//		private static final String OMNITURE_IMPORT_DELIMITER = "\u0002";
		private static final String OMNITURE_IMPORT_DELIMITER = "\t";
		RecordWriter recordWriter;
		
		public OmnitureRecordWriter(RecordWriter recordWriter) {
			this.recordWriter = recordWriter;
		}

		@Override
		public void close(Reporter arg0) throws IOException {
			this.recordWriter.close(arg0);
		}

		@Override
		public void write(Object key, Object value) throws IOException {
			//this method call should always get an OmnitureWritable as value
			if (value instanceof OmnitureWritable){
                StringBuilder sb = new StringBuilder();
                OmnitureWritable ow = (OmnitureWritable)value; 
				Date d = new Date(ow.getClickDate());
                SimpleDateFormat dFormat = new SimpleDateFormat("MM/dd/yyhh:mm:ss");
                sb.append(dFormat.format(d))
                	.append( OMNITURE_IMPORT_DELIMITER).append(ow.getMid())
					.append( OMNITURE_IMPORT_DELIMITER).append(ow.getTid ())
					.append( OMNITURE_IMPORT_DELIMITER).append(ow.getRequestPageStr())
					.append( OMNITURE_IMPORT_DELIMITER).append(ow.getRequestDynamicStr())
					.append( OMNITURE_IMPORT_DELIMITER).append(ow.getReferrerPageStr())
					.append( OMNITURE_IMPORT_DELIMITER).append(ow.getReferrerDynamicStr ())
					.append( OMNITURE_IMPORT_DELIMITER).append(ow.getStatus())
					.append( OMNITURE_IMPORT_DELIMITER).append(ow.getUserAgent())
					.append( OMNITURE_IMPORT_DELIMITER).append(ow.geteSiteSessionKey())
					.append( OMNITURE_IMPORT_DELIMITER).append(ow.getFebsecSessionKey())
					.append( OMNITURE_IMPORT_DELIMITER).append(ow.getSequenceNum())
					.append( OMNITURE_IMPORT_DELIMITER).append(ow.getFebsecCoAttributes ())
					.append( OMNITURE_IMPORT_DELIMITER).append(ow.getIpAddr())
					.append( OMNITURE_IMPORT_DELIMITER).append(ow.getMid())
					.append( OMNITURE_IMPORT_DELIMITER).append(ow.getRelMap())
					.append( OMNITURE_IMPORT_DELIMITER).append(ow.getSessionFlag())
					.append( OMNITURE_IMPORT_DELIMITER).append(ow.getRole())
					.append( OMNITURE_IMPORT_DELIMITER).append(ow.getAssocFlag())
					.append( OMNITURE_IMPORT_DELIMITER).append(ow.getDwellTime());

                this.recordWriter.write(NullWritable.get(), new Text(sb.toString()));
			}else{
				this.recordWriter.write(NullWritable.get(), new Text(value.toString()));
			}
		}
		
	}
}
