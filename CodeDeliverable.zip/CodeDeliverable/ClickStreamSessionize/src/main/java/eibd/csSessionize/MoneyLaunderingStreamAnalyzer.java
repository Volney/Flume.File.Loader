package eibd.csSessionize;

public class MoneyLaunderingStreamAnalyzer {

	TIDCompositeKey lagKey;
	long lagFundCount = 0;
	long lagWithdrawCount = 0;
	long lagOtherCount = 0;
	
	
	public MoneyLaunderingStreamAnalyzer() {
		
	}
	
	public void newClick(TIDCompositeKey key, String click) {
		
		if (isLogInEvent( key, click)) {
			lagFundCount = 0;
			lagWithdrawCount = 0;
			lagOtherCount = 0;
		}
	}
	
	private boolean isLogInEvent(TIDCompositeKey key, String click) {
		return false;
	}
	
	private boolean isFundEvent(TIDCompositeKey key, String click) {
		return false;
	}

	private boolean isWithdrawEvent(TIDCompositeKey key, String click) {
		return false;
	}
	private boolean isLogOutEvent(TIDCompositeKey key, String click) {
		return false;
	}
	
	private boolean isMLFundSession() {
		if (lagFundCount > 1 && lagWithdrawCount == 0) {
			return true;
		}
		return false;
	}
	
	private boolean isMLWithdrawSession() {
		if (lagFundCount == 0 && lagWithdrawCount > 1) {
			return true;
		}
		return false;
	}
	
}
