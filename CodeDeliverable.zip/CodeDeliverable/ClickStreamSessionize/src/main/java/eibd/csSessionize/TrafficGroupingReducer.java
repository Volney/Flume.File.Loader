package eibd.csSessionize;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;

// this will just be the identity reducer
public class TrafficGroupingReducer extends MapReduceBase
			implements Reducer<TIDCompositeKey, OmnitureWritable, NullWritable, Text> {

	private static final String EMPTY_FIELD_VALUE = "-";
	private static final String DEBUG_NODE_IDENTIFIER = "DEBUG_TGREDUCE_NODE";
	private static final String DEBUG_IDENTIFIER = "DEBUG_TRAFFIC_GROUPING_REDUCER";
	private static final String SESSION_STATUS_NORMAL = "0";
	private static final String DOMAIN_NAME_FPS = "fps";
	private static final String DOMAIN_NAME_WWW = "www";
	private static final String SESSION_STATUS_ONE_HIT_WONDER = "8";
	private static final long SESSION_IMEOUT_PERIOD_IN_MS = 30*60*1000;
	
	/** Debug Variables **/
	protected boolean debug = false;
	protected int numReduceTasks = 0;
	protected int debugNode = 0;
	protected int currentNode = -1;
	protected boolean debugActivated = false;
	protected StringBuilder debugString = new StringBuilder();
	protected ArrayList<OmnitureWritable> buffer = new ArrayList<OmnitureWritable>(5);
	

	public static enum TGReducerTrafficStats{MIDSPLATTER, MISSING_MID, SEQNUM_INCREMENTED, ONEHIT_TEST, ONEHIT_SINGLEROW, ONEHIT_SAMESESSION, ONEHIT_SINGLEROWSESSION, ONEHIT_PREVROW};
	
	@Override
	public void configure(JobConf job) {
		super.configure(job);
		this.debug = job.getBoolean(DEBUG_IDENTIFIER, false);
		this.numReduceTasks = job.getNumReduceTasks();
		this.debugNode = job.getInt(DEBUG_NODE_IDENTIFIER, 0);
	}
	
	@Override
	public void reduce(TIDCompositeKey key, Iterator<OmnitureWritable> values,
		      OutputCollector<NullWritable, Text> output, Reporter reporter) 	
		      throws IOException {

		//debug code
		if (this.debug){
			if (!this.debugActivated){
				if (this.currentNode <0){
					this.currentNode = Math.abs(key.getTid().hashCode() * 127) % this.numReduceTasks;
				}
				if (this.currentNode == this.debugNode){
					this.debugActivated = true;
				}
				debugString.setLength(0);
			}
		}
		
		if (debugActivated) 
			System.out.println("DEBUG INITIALIZED ON REDUCER NODE: [" + this.currentNode + "] for KEY: " + key);
		
		//initialize - by processing the first row, to be set the past history during cyclic processing
		if (debugActivated) debugString.append("1>");
		if (values.hasNext()){
			if (debugActivated) debugString.append("2>");
//			buffer.add(values.next());
			int ctr = 0;
			while (values.hasNext() && ctr < 5){
				if (debugActivated) debugString.append("6>");
				buffer.add(values.next().clone());
				ctr++;
			}
			buffer.get(0).setSequenceNum(0);
			if (buffer.get(0).getMid().equals(EMPTY_FIELD_VALUE)){
				if (debugActivated) debugString.append("3>");
				reporter.incrCounter(TGReducerTrafficStats.MISSING_MID, 1);
				reporter.incrCounter(TGReducerTrafficStats.ONEHIT_TEST, 1);
				if (buffer.size() == 1){
					if (debugActivated) debugString.append("4>");
					//if this is the only row in this TID - it is definitely a one hit wonder
					buffer.get(0).setSessionFlag(SESSION_STATUS_ONE_HIT_WONDER);
					reporter.incrCounter(TGReducerTrafficStats.ONEHIT_SINGLEROW, 1);
				}else{
					if (debugActivated) debugString.append("5>");
					//test if this row is in the same session as the next row
					sessionizeAndTestOneHitWonder(buffer, 0, reporter, debugString);
				}
			}else{
				if (debugActivated) debugString.append("7>");
				buffer.get(0).setSessionFlag(SESSION_STATUS_NORMAL);
			}
			if (debugActivated) debugString.append("8>");
			//process current row (row 1 in buffer) in conjunction with previous row (row 0 in buffer) 
			//and future rows (rows 2 thru 4 in buffer)
			while (!buffer.isEmpty()){
				if (debugActivated) debugString.append("9>");
				//process only if more than 1 row in buffer. First row is already pre-processed
				if (buffer.size()>1){
					if (debugActivated) debugString.append("10>");
					//do mid splattering if applicable
					if (buffer.get(1).getMid().equals(EMPTY_FIELD_VALUE)){
						if (debugActivated) debugString.append("11>");
						reporter.incrCounter(TGReducerTrafficStats.MISSING_MID, 1);
						reporter.incrCounter(TGReducerTrafficStats.MIDSPLATTER, 1);
						buffer.get(1).setMid(buffer.get(0).getMid());
					}
					//do seq counting if applicable
					if (buffer.get(1).getClickDate()==buffer.get(0).getClickDate()){
						if (debugActivated) debugString.append("12>");
						reporter.incrCounter(TGReducerTrafficStats.SEQNUM_INCREMENTED, 1);
						buffer.get(1).setSequenceNum(buffer.get(0).getSequenceNum()+1);
					}
					//do one hit wonder, only if MID is still missing
					if (buffer.get(1).getMid().equals(EMPTY_FIELD_VALUE)){
						if (debugActivated) debugString.append("13>");
						reporter.incrCounter(TGReducerTrafficStats.ONEHIT_TEST, 1);
						if ((buffer.get(0).getClickDate() - buffer.get(1).getClickDate())< SESSION_IMEOUT_PERIOD_IN_MS){
							if (debugActivated) debugString.append("14>");
							//if current row is in the same session as previous row, then the session flag will be the same.
							buffer.get(1).setSessionFlag(buffer.get(0).getSessionFlag());
							reporter.incrCounter(TGReducerTrafficStats.ONEHIT_PREVROW, 1);
						}else{
							if (debugActivated) debugString.append("15>");
							sessionizeAndTestOneHitWonder(buffer, 1, reporter, debugString);
						} //end of MID check
					}else{
						if (debugActivated) debugString.append("16>");
						buffer.get(1).setSessionFlag(SESSION_STATUS_NORMAL);
					}
				}
				if (debugActivated) debugString.append("17>");
				//pop row0 from buffer and emit
				Text newText = new Text(buffer.get(0).toString());
				
				output.collect(NullWritable.get(), newText);
				buffer.remove(0);
				//push new row into buffer
				if (values.hasNext()){
					if (debugActivated) debugString.append("18>");
					buffer.add(values.next().clone());
				}
			} //end of while
		} //end of iterator test
		if (debugActivated) debugString.append("19>");
		if (debugActivated) System.out.println(debugString.toString());
	} //end of reduce method

	/**
	 * @param buffer
	 * @param currentRowIndex
	 * @param reporter 
	 */
	private void sessionizeAndTestOneHitWonder(
			ArrayList<OmnitureWritable> buffer,
			int currentRowIndex, Reporter reporter, 
			StringBuilder debugString) {
		
		if (debugActivated) debugString.append("20>");
		//current row is not in session with previous row.
		int pagesFoundInSession = 1;
		for (int i=currentRowIndex; i < buffer.size()-1; i++){
			if (debugActivated) debugString.append("21>");
			//test if in same session
			if ((buffer.get(i).getClickDate()-buffer.get(i+1).getClickDate()) < SESSION_IMEOUT_PERIOD_IN_MS){
				if (debugActivated) debugString.append("22>");
				pagesFoundInSession++;
			}else{
				if (debugActivated) debugString.append("23>");
				break;
			}
		}
		if (pagesFoundInSession == 1){
			if (debugActivated) debugString.append("24>");
			buffer.get(currentRowIndex).setSessionFlag(SESSION_STATUS_ONE_HIT_WONDER);
			reporter.incrCounter(TGReducerTrafficStats.ONEHIT_SINGLEROWSESSION, 1);
		}else if (pagesFoundInSession<4){
			if (debugActivated) debugString.append("25>");
			//test for page type - how?
			boolean wwwTest = true;
			boolean fpsTest = true;
			for (int j=currentRowIndex; j<pagesFoundInSession; j++){
				if (debugActivated) debugString.append("26>");
				wwwTest = wwwTest && buffer.get(j).getRequestPageStr().startsWith(DOMAIN_NAME_WWW);
				fpsTest = fpsTest && buffer.get(j).getRequestPageStr().startsWith(DOMAIN_NAME_FPS);
			}
			//test the domain against being www or fps?
			if (wwwTest || fpsTest){
				if (debugActivated) debugString.append("27>");
				buffer.get(currentRowIndex).setSessionFlag(SESSION_STATUS_ONE_HIT_WONDER);
				reporter.incrCounter(TGReducerTrafficStats.ONEHIT_SAMESESSION, 1);
			}else{
				if (debugActivated) debugString.append("28>");
				buffer.get(currentRowIndex).setSessionFlag(SESSION_STATUS_NORMAL);
			}
		}
	}
}
