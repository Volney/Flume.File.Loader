package eibd.csSessionize;

import java.util.regex.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.String;
import java.util.ArrayList;
import java.util.StringTokenizer;
	
public class Filter {
	public static void main(String[] args) throws IOException {
        boolean testResult = false;
        //testResult = testForFilter("/netbenefits/navstation/navbar?fidlink=y", "Mozilla", "metrics");

        BufferedReader input = new BufferedReader(new FileReader("C:/akamai_111214"));
        FileWriter output = new FileWriter("C:/filter.out", true);
        try {
			String logEntry = input.readLine();
	        Integer logCount = 0;
	        Integer keptCount = 0;
			while (logEntry != null)
			{
			   StringTokenizer tokenizer = new StringTokenizer(logEntry, "\t");
			   int tokenCount = 0;
			   String[] tokenArray = new String[tokenizer.countTokens()];
			   while (tokenCount <= tokenizer.countTokens()) {
				 tokenArray[tokenCount++] = tokenizer.nextToken();
			   }
			   testResult = testForFilter(tokenArray[9] + "?" + tokenArray[10], tokenArray[7], "www");
		       //System.out.println("Test result:" + testResult);
		       if (!testResult) 
		       {
		    	   keptCount++;
		    	   output.write(logEntry + "\n");
		       }
		       logEntry = input.readLine();
		       logCount++;
			}
			input.close();
			output.close();
			System.out.println("Total Read: " + logCount.toString() + " Kept: " + keptCount.toString());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

	public static boolean testForFilter(String requestWithQuery, String agent, String filename)
	{
       boolean filterStatus = false;
       ArrayList<Matcher> reqPatterns = new ArrayList<Matcher>();
       ArrayList<Matcher> agentPatterns = new ArrayList<Matcher> ();
       ArrayList<Matcher> nbPatterns = new ArrayList<Matcher> ();
       
       
       String[] requestParams = requestWithQuery.split("\\?");
       String request;
	   String requestQuery;
       if (requestParams.length > 1) {
    	   request = requestParams[0];
    	   requestQuery = requestParams[1];
       } else {
    	   request = requestParams[0];
    	   requestQuery = "";
       }
       //if (request.length() > 2) {
       //request = request.substring(1);
       //request = request.substring(0,request.length()-1); }
       //request.replaceAll("^\\","");
       
       //if (requestQuery.length() > 2 && requestQuery != null) {
       //requestQuery = requestQuery.substring(1);
       //requestQuery = requestQuery.substring(0,requestQuery.length()-1); }
       //requestQuery.replaceAll("^\\","");
       //System.out.println("Request=" + request);
       // Request URL matches
       
       Pattern images = Pattern.compile(".*\\.(gif|jpeg|jpg|png|bmp)", Pattern.CASE_INSENSITIVE);
       Matcher imagesMatch = images.matcher(request);
       Pattern gif = Pattern.compile(".*\\.gif");
       Matcher gifMatcher = gif.matcher(request);
       Pattern filetypes = Pattern.compile(".*\\.(css|xsl|dll|xml|txt|class|js)$", Pattern.CASE_INSENSITIVE);
       Matcher ftMatcher = filetypes.matcher(request);
       Pattern exeFiletype = Pattern.compile(".*\\.exe");
       Matcher exeMatcher = exeFiletype.matcher(request);
       Pattern urlmatches = Pattern.compile(".*(nudge|aaaaa|\\+\\+\\+\\+\\+|_toc|_nav|\\/nav\\/htmlnavs\\/index1t\\.shtml|\\/cgi-bin\\/f5monitor\\.html|\\/x-tree\\/f5monitor\\.html|\\<script\\>|favicon\\.ico).*", Pattern.CASE_INSENSITIVE);
       Matcher urlMatcher = urlmatches.matcher(request);
       Pattern flashMatches = Pattern.compile("\\/flash\\/chart\\.phtml", Pattern.CASE_INSENSITIVE);
       Matcher flashMatcher = flashMatches.matcher(request);
       Pattern f5matches = Pattern.compile(".*\\/x\\-tree\\/f5monitor\\.html.*", Pattern.CASE_INSENSITIVE);
       Matcher f5Matcher = f5matches.matcher(request);
       Pattern blanks = Pattern.compile(".*blank([\\._]?s?html|frame|_page\\.html)", Pattern.CASE_INSENSITIVE);
       Matcher blkMatcher = blanks.matcher(request);
       Pattern slashes = Pattern.compile("\\/[^\\/^\\.]{20}[^\\/^\\.]* .*", Pattern.CASE_INSENSITIVE);
       Matcher slashMatcher = slashes.matcher(request);
       Pattern mflfidnet = Pattern.compile(".*\\/gen\\/(mflnet\\/[a-zA-Z0-9]+|mflfid\\/[a-zA-Z0-9]+|apl)\\/[a-zA-Z0-9]+[_\\.](?!dat).*", Pattern.CASE_INSENSITIVE);
       Matcher mflMatcher = mflfidnet.matcher(request);
       reqPatterns.add(ftMatcher);
       reqPatterns.add(urlMatcher);
       reqPatterns.add(blkMatcher);
       reqPatterns.add(slashMatcher);
       reqPatterns.add(mflMatcher);
       reqPatterns.add(f5Matcher);
       // User Agent matches
       Pattern agentmatches = Pattern.compile(".*(IOC|IOPS|FidelityGetter|GuyReshRules|Charlotte|Crawler|OVIS|KTXN|GomezAgent|UUNET\\/checktime|Googlebot|AdsBot-Google|InetClntApp).*", Pattern.CASE_INSENSITIVE);
       Matcher agentMatcher = agentmatches.matcher(agent);
       Pattern agent2matches = Pattern.compile(".*(libwww|LWP::Simple|lwp-trivial|Powermarks|Slurp|Spider|Jakarta Commons|sitescope).*", Pattern.CASE_INSENSITIVE);
       Matcher agent2Matcher = agent2matches.matcher(agent);
       Pattern moz2matches = Pattern.compile("Mozilla\\/2.0 \\(?compatible.*", Pattern.CASE_INSENSITIVE);
       Matcher moz2Matcher = moz2matches.matcher(agent);
       Pattern moz3matches = Pattern.compile("Mozilla\\/3\\.01?( \\(compatible;\\)| \\[en\\]\\(Win95; I\\))?.*", Pattern.CASE_INSENSITIVE);
       Matcher moz3Matcher = moz3matches.matcher(agent);
       Pattern moz4matches = Pattern.compile("Mozilla\\/4\\.0 \\(compatible; Win32; WinHttp.WinHttpRequest.5\\).*", Pattern.CASE_INSENSITIVE);
       Matcher moz4Matcher = moz4matches.matcher(agent);
       agentPatterns.add(agentMatcher);
       agentPatterns.add(agent2Matcher);
       agentPatterns.add(moz2Matcher);
       agentPatterns.add(moz3Matcher);
       agentPatterns.add(moz4Matcher);
       //NetBen matches
       Pattern nbreqmatches = Pattern.compile(".*(\\.\\.|\\/blankbkg\\.htm|\\/empty\\.htm|style_guide|system32|\\/toc\\.htm|\\/_vti).*", Pattern.CASE_INSENSITIVE);
       Matcher nbreqMatcher = nbreqmatches.matcher(agent);
       Pattern nbfiletypes = Pattern.compile(".*\\.(cfm|inc|ini|log|nsf|php|printer)", Pattern.CASE_INSENSITIVE);
       Matcher nbfileMatcher = nbfiletypes.matcher(agent);
       nbPatterns.add(nbreqMatcher);
       nbPatterns.add(nbfileMatcher);
       //Special matching conditions
       Pattern isNetBen = Pattern.compile("^(workplaceservices|plansponsorservices|acbs|hrsolutions).*", Pattern.CASE_INSENSITIVE);
       Matcher isNBMatch = isNetBen.matcher(filename);
       Pattern isIncomePlnr = Pattern.compile("^incomeplanner.*", Pattern.CASE_INSENSITIVE);
       Matcher isIPMatch = isIncomePlnr.matcher(filename);
       Pattern isATP = Pattern.compile(".*atp.*", Pattern.CASE_INSENSITIVE);
       Matcher isATPMatch = isATP.matcher(filename);
       Pattern NBNav = Pattern.compile(".*\\/netbenefits\\/navstation\\/navbar.*", Pattern.CASE_INSENSITIVE);
       Matcher isNBNavMatcher = NBNav.matcher(request);
       Pattern NBQuery = Pattern.compile("fidlink\\=y", Pattern.CASE_INSENSITIVE);
       Matcher isNBQueryMatcher = NBQuery.matcher(requestQuery);
       Pattern annuityMatches = Pattern.compile(".*\\/planner\\/images\\/annuitytracker\\.gif", Pattern.CASE_INSENSITIVE);
       Matcher isAnnuityMatch = annuityMatches.matcher(request);
       Pattern quoteMatch = Pattern.compile(".*quote.*", Pattern.CASE_INSENSITIVE);
       Matcher isQuoteMatch = quoteMatch.matcher(filename);
       
       //if (gifMatcher.matches()) { System.out.println("Image Request: " + request + " Image filename: " + filename); } 

       //Test for images - filter out most images, only a few are allowed
       filterStatus = imagesMatch.matches();
       if (filterStatus == true) {
           //System.out.println("Image Request: " + request + " Image filename: " + filename);
    	   if (isIPMatch.matches() && isAnnuityMatch.matches())
           {
    	      filterStatus = false;
           }
       }
       
       //Test for .exe, only NB and ATP exe's are allowed
       if (!filterStatus) 
       {
          if (exeMatcher.matches())
          {
        	  if (isNBMatch.matches() || isATPMatch.matches())
        	  {
        		  filterStatus = false;
        	  }
        	  else
        	  {
        		  filterStatus = true;
        	  }
          }
       }
       
       //Test for /flash/chart.phtml - any from quote server are filtered
       if (!filterStatus) 
       {
          if (flashMatcher.matches() && isQuoteMatch.matches()) 
          {
        	 filterStatus = true;
          }
       }
       
       //Test for Request Patterns
       int i = 0;
       while (i < reqPatterns.size() && filterStatus == false)
       {
    	  Matcher reqMatcher = reqPatterns.get(i);
          filterStatus = reqMatcher.matches();
          i++;
       }
       //Test for User Agent Patterns
       int j = 0;
       while (j < agentPatterns.size() && filterStatus == false)
       {
    	   Matcher agntMatcher = agentPatterns.get(j);
          filterStatus = agntMatcher.matches();
          j++;
       }
       //Special NB Tests
       if (isNBMatch.matches())
       {
           int k = 0;
           while (k < nbPatterns.size() && filterStatus == false)
           {
        	  Matcher nbMatcher = nbPatterns.get(k);
              filterStatus = nbMatcher.matches();
              k++;
           }
       }
       if (!filterStatus && isNBMatch.matches() && isNBNavMatcher.matches())
       {
    	   if (isNBQueryMatcher.matches())
    	   {
    		   filterStatus = false;
    	   }
    	   else
    	   {
    		   filterStatus = true;
    	   }
       }
       
       return filterStatus;
	}
	
	public static String filterClickpairs(String requestQuery)
	{
       String newQuery = "";
       ArrayList<String> WhiteList = new ArrayList<String>();
       
       //Populate the WhiteList
       WhiteList.add("abemail");
       WhiteList.add("acctnum");
       WhiteList.add("action");
       WhiteList.add("actionkey");
       WhiteList.add("ad");
       WhiteList.add("amazon");
       WhiteList.add("anchorid");
       WhiteList.add("annuover10");
       WhiteList.add("aosource");
       WhiteList.add("appttime");
       WhiteList.add("ar");
       WhiteList.add("articleid");
       WhiteList.add("ask");
       WhiteList.add("banner");
       WhiteList.add("bar");
       WhiteList.add("bfpsource");
       WhiteList.add("billpay");
       WhiteList.add("bizid");
       WhiteList.add("boffer");
       WhiteList.add("bplace");
       WhiteList.add("button");
       WhiteList.add("cat");
       WhiteList.add("category");
       WhiteList.add("ccorigin");
       WhiteList.add("ccsource");
       WhiteList.add("cid");
       WhiteList.add("city");
       WhiteList.add("client");
       WhiteList.add("clientid");
       WhiteList.add("clientlist");
       WhiteList.add("clientnv1");
       WhiteList.add("clientnv10");
       WhiteList.add("clientnv11");
       WhiteList.add("clientnv12");
       WhiteList.add("clientnv13");
       WhiteList.add("clientnv14");
       WhiteList.add("clientnv15");
       WhiteList.add("clientnv16");
       WhiteList.add("clientnv17");
       WhiteList.add("clientnv18");
       WhiteList.add("clientnv2");
       WhiteList.add("clientnv3");
       WhiteList.add("clientnv4");
       WhiteList.add("clientnv5");
       WhiteList.add("clientnv6");
       WhiteList.add("clientnv7");
       WhiteList.add("clientnv8");
       WhiteList.add("clientnv9");
       WhiteList.add("command");
       WhiteList.add("confirmid");
       WhiteList.add("content");
       WhiteList.add("context");
       WhiteList.add("courseid");
       WhiteList.add("cr");
       WhiteList.add("crtype");
       WhiteList.add("csp_email");
       WhiteList.add("cusip");
       WhiteList.add("dashapp");
       WhiteList.add("dashexit");
       WhiteList.add("dc_toc");
       WhiteList.add("dd");
       WhiteList.add("destinationlink");
       WhiteList.add("displaystate");
       WhiteList.add("dm");
       WhiteList.add("doctype");
       WhiteList.add("dowait");
       WhiteList.add("edit");
       WhiteList.add("ek_search_query");
       WhiteList.add("ekitcode");
       WhiteList.add("election_oga_ind");
       WhiteList.add("em");
       WhiteList.add("email");
       WhiteList.add("emailcatid");
       WhiteList.add("error_code");
       WhiteList.add("eventdate");
       WhiteList.add("evntid");
       WhiteList.add("exittarget");
       WhiteList.add("expertstrategy");
       WhiteList.add("eyofrom");
       WhiteList.add("fca_id");
       WhiteList.add("feedid");
       WhiteList.add("fefrom");
       WhiteList.add("feplanid");
       WhiteList.add("fggivar");
       WhiteList.add("ficreate");
       WhiteList.add("fid_pub");
       WhiteList.add("fidbizid");
       WhiteList.add("fidlink");
       WhiteList.add("filoc");
       WhiteList.add("firef");
       WhiteList.add("formname");
       WhiteList.add("fpra_exchangepercentage");
       WhiteList.add("fpra_frpafund");
       WhiteList.add("fpra_jointownerage");
       WhiteList.add("fpra_jointownerretage");
       WhiteList.add("fpra_leavebehindpercentage");
       WhiteList.add("fpra_marginaltaxrate");
       WhiteList.add("fpra_nofprafund");
       WhiteList.add("fpra_nofprapercentage");
       WhiteList.add("fpra_ownerage");
       WhiteList.add("fpra_ownerretage");
       WhiteList.add("fpra_savingamountfpra");
       WhiteList.add("fpra_savingamountnofpra");
       WhiteList.add("fromhpbricklet");
       WhiteList.add("fromloc");
       WhiteList.add("fromlocation");
       WhiteList.add("frommenu");
       WhiteList.add("frompage");
       WhiteList.add("frompageln");
       WhiteList.add("fs");
       WhiteList.add("fscat");
       WhiteList.add("fsr");
       WhiteList.add("group");
       WhiteList.add("hosted");
       WhiteList.add("hp_msg");
       WhiteList.add("hrsbanner");
       WhiteList.add("hrscontext");
       WhiteList.add("imm_aid");
       WhiteList.add("imm_cid");
       WhiteList.add("imm_eid");
       WhiteList.add("imm_pid");
       WhiteList.add("immid");
       WhiteList.add("impressions");
       WhiteList.add("imtranscript");
       WhiteList.add("incometype");
       WhiteList.add("industry");
       WhiteList.add("intro_page");
       WhiteList.add("invocationtype");
       WhiteList.add("ip");
       WhiteList.add("ipoint");
       WhiteList.add("ipointnv1");
       WhiteList.add("ipointnv10");
       WhiteList.add("ipointnv11");
       WhiteList.add("ipointnv12");
       WhiteList.add("ipointnv13");
       WhiteList.add("ipointnv14");
       WhiteList.add("ipointnv15");
       WhiteList.add("ipointnv16");
       WhiteList.add("ipointnv17");
       WhiteList.add("ipointnv18");
       WhiteList.add("ipointnv2");
       WhiteList.add("ipointnv3");
       WhiteList.add("ipointnv4");
       WhiteList.add("ipointnv5");
       WhiteList.add("ipointnv6");
       WhiteList.add("ipointnv7");
       WhiteList.add("ipointnv8");
       WhiteList.add("ipointnv9");
       WhiteList.add("ipqtam");
       WhiteList.add("key");
       WhiteList.add("kit");
       WhiteList.add("ksearch");
       WhiteList.add("kw");
       WhiteList.add("lc");
       WhiteList.add("le_subctx");
       WhiteList.add("link");
       WhiteList.add("location");
       WhiteList.add("lzone");
       WhiteList.add("mailprefoption");
       WhiteList.add("med");
       WhiteList.add("mediafile");
       WhiteList.add("mflchart");
       WhiteList.add("mgg_incomestart");
       WhiteList.add("mggi_buttonname");
       WhiteList.add("mggi_custage");
       WhiteList.add("mggi_income");
       WhiteList.add("mggi_invamt");
       WhiteList.add("mggi_market");
       WhiteList.add("mggi_spouseage");
       WhiteList.add("misc");
       WhiteList.add("mptohp");
       WhiteList.add("ms_ovwid");
       WhiteList.add("msc");
       WhiteList.add("msgname");
       WhiteList.add("mt");
       WhiteList.add("myplan");
       WhiteList.add("nbfund");
       WhiteList.add("newstitle");
       WhiteList.add("nsrplastpage");
       WhiteList.add("nsrpminisnap");
       WhiteList.add("nsrpnewsprovider");
       WhiteList.add("nsrppageselected");
       WhiteList.add("nsrpsortby");
       WhiteList.add("nsrpticker");
       WhiteList.add("nsrptradebutton");
       WhiteList.add("oad");
       WhiteList.add("offer");
       WhiteList.add("offernv1");
       WhiteList.add("offernv10");
       WhiteList.add("offernv11");
       WhiteList.add("offernv12");
       WhiteList.add("offernv13");
       WhiteList.add("offernv14");
       WhiteList.add("offernv15");
       WhiteList.add("offernv16");
       WhiteList.add("offernv17");
       WhiteList.add("offernv18");
       WhiteList.add("offernv2");
       WhiteList.add("offernv3");
       WhiteList.add("offernv4");
       WhiteList.add("offernv5");
       WhiteList.add("offernv6");
       WhiteList.add("offernv7");
       WhiteList.add("offernv8");
       WhiteList.add("offernv9");
       WhiteList.add("originatingpage");
       WhiteList.add("os");
       WhiteList.add("p");
       WhiteList.add("page");
       WhiteList.add("pageaction");
       WhiteList.add("pageid");
       WhiteList.add("pagename");
       WhiteList.add("pagetoload");
       WhiteList.add("partner");
       WhiteList.add("paswfrom");
       WhiteList.add("plan");
       WhiteList.add("planid");
       WhiteList.add("plannum");
       WhiteList.add("plannv1");
       WhiteList.add("plannv10");
       WhiteList.add("plannv11");
       WhiteList.add("plannv12");
       WhiteList.add("plannv13");
       WhiteList.add("plannv14");
       WhiteList.add("plannv15");
       WhiteList.add("plannv16");
       WhiteList.add("plannv17");
       WhiteList.add("plannv18");
       WhiteList.add("plannv2");
       WhiteList.add("plannv3");
       WhiteList.add("plannv4");
       WhiteList.add("plannv5");
       WhiteList.add("plannv6");
       WhiteList.add("plannv7");
       WhiteList.add("plannv8");
       WhiteList.add("plannv9");
       WhiteList.add("popetf");
       WhiteList.add("portsm");
       WhiteList.add("priclient");
       WhiteList.add("product");
       WhiteList.add("productid");
       WhiteList.add("producttype");
       WhiteList.add("prospectus");
       WhiteList.add("ps");
       WhiteList.add("psite");
       WhiteList.add("pvn");
       WhiteList.add("q");
       WhiteList.add("query");
       WhiteList.add("question");
       WhiteList.add("question_box");
       WhiteList.add("quser");
       WhiteList.add("rdc_landing");
       WhiteList.add("ref");
       WhiteList.add("ref_529");
       WhiteList.add("ref_at");
       WhiteList.add("ref_ca");
       WhiteList.add("ref_fiover");
       WhiteList.add("ref_ls");
       WhiteList.add("ref_mag");
       WhiteList.add("ref_rfi");
       WhiteList.add("ref_ro");
       WhiteList.add("ref_whyfid");
       WhiteList.add("refann");
       WhiteList.add("refer");
       WhiteList.add("referral_cd");
       WhiteList.add("refhp");
       WhiteList.add("refpr");
       WhiteList.add("refsearch");
       WhiteList.add("refurl");
       WhiteList.add("region");
       WhiteList.add("regionid");
       WhiteList.add("rep");
       WhiteList.add("repfr");
       WhiteList.add("repid");
       WhiteList.add("repkiosk");
       WhiteList.add("report");
       WhiteList.add("reportname");
       WhiteList.add("reqtype");
       WhiteList.add("requestfrom");
       WhiteList.add("resann");
       WhiteList.add("results");
       WhiteList.add("resultsview");
       WhiteList.add("ro");
       WhiteList.add("roas");
       WhiteList.add("roc");
       WhiteList.add("roed");
       WhiteList.add("rolc");
       WhiteList.add("rolloverfrom");
       WhiteList.add("roplc");
       WhiteList.add("rose");
       WhiteList.add("rospc");
       WhiteList.add("rospdf");
       WhiteList.add("rospr");
       WhiteList.add("rosprr");
       WhiteList.add("ross");
       WhiteList.add("rosss");
       WhiteList.add("rpqtam");
       WhiteList.add("rqcadjust");
       WhiteList.add("rqcassets");
       WhiteList.add("rqcpreview");
       WhiteList.add("rqcqt");
       WhiteList.add("rsrvdptyid");
       WhiteList.add("rssfrom");
       WhiteList.add("rssorig");
       WhiteList.add("rt");
       WhiteList.add("rvd");
       WhiteList.add("rvn");
       WhiteList.add("salary");
       WhiteList.add("scn");
       WhiteList.add("screener");
       WhiteList.add("search");
       WhiteList.add("searchquery");
       WhiteList.add("sector");
       WhiteList.add("sell");
       WhiteList.add("seqid");
       WhiteList.add("sessionid");
       WhiteList.add("sfund");
       WhiteList.add("showbalance");
       WhiteList.add("showotheraccounts");
       WhiteList.add("sid");
       WhiteList.add("simplestrategy");
       WhiteList.add("singlefund");
       WhiteList.add("siteid");
       WhiteList.add("smccampaign");
       WhiteList.add("smcfrom");
       WhiteList.add("smlabel");
       WhiteList.add("solntype");
       WhiteList.add("source");
       WhiteList.add("sourcecd");
       WhiteList.add("spccr");
       WhiteList.add("spclr");
       WhiteList.add("spor");
       WhiteList.add("spssr");
       WhiteList.add("spvar");
       WhiteList.add("srbricklet");
       WhiteList.add("src");
       WhiteList.add("srcindex");
       WhiteList.add("srcsearch");
       WhiteList.add("srctype");
       WhiteList.add("srlandingpage");
       WhiteList.add("ss_command");
       WhiteList.add("st_research");
       WhiteList.add("state");
       WhiteList.add("statecode");
       WhiteList.add("strategytype");
       WhiteList.add("svcmodfn");
       WhiteList.add("svcmodule");
       WhiteList.add("tab");
       WhiteList.add("taskprocessed");
       WhiteList.add("tbpage");
       WhiteList.add("tbversion");
       WhiteList.add("terms");
       WhiteList.add("tkc");
       WhiteList.add("toasubmit");
       WhiteList.add("toc");
       WhiteList.add("tracking");
       WhiteList.add("trackingcode");
       WhiteList.add("trackingnv1");
       WhiteList.add("trackingnv10");
       WhiteList.add("trackingnv11");
       WhiteList.add("trackingnv12");
       WhiteList.add("trackingnv13");
       WhiteList.add("trackingnv14");
       WhiteList.add("trackingnv15");
       WhiteList.add("trackingnv16");
       WhiteList.add("trackingnv17");
       WhiteList.add("trackingnv18");
       WhiteList.add("trackingnv2");
       WhiteList.add("trackingnv3");
       WhiteList.add("trackingnv4");
       WhiteList.add("trackingnv5");
       WhiteList.add("trackingnv6");
       WhiteList.add("trackingnv7");
       WhiteList.add("trackingnv8");
       WhiteList.add("trackingnv9");
       WhiteList.add("trade");
       WhiteList.add("txn_name");
       WhiteList.add("txn_type");
       WhiteList.add("txs");
       WhiteList.add("typeln");
       WhiteList.add("url01");
       WhiteList.add("ut");
       WhiteList.add("uuid");
       WhiteList.add("version");
       WhiteList.add("view");
       WhiteList.add("viewname");
       WhiteList.add("vs_search_source");
       WhiteList.add("vsassetid");
       WhiteList.add("vsauthor");
       WhiteList.add("vsbricklet");
       WhiteList.add("vschannel");
       WhiteList.add("vscl");
       WhiteList.add("vscoid");
       WhiteList.add("vsdate");
       WhiteList.add("vsdesc");
       WhiteList.add("vsdesc2");
       WhiteList.add("vsdr");
       WhiteList.add("vsdt");
       WhiteList.add("vsergclnt");
       WhiteList.add("vsevent");
       WhiteList.add("vsextid");
       WhiteList.add("vsheadline");
       WhiteList.add("vsindex");
       WhiteList.add("vslid");
       WhiteList.add("vsmodule");
       WhiteList.add("vsorigin");
       WhiteList.add("vspa");
       WhiteList.add("vspage");
       WhiteList.add("vspagetag");
       WhiteList.add("vspgid");
       WhiteList.add("vspgtemp");
       WhiteList.add("vspgver");
       WhiteList.add("vspl");
       WhiteList.add("vsprod");
       WhiteList.add("vspurp");
       WhiteList.add("vsregtype");
       WhiteList.add("vsrelevancy");
       WhiteList.add("vsrid");
       WhiteList.add("vsrole");
       WhiteList.add("vssearchphrase");
       WhiteList.add("vssecsub");
       WhiteList.add("vssource");
       WhiteList.add("vssrcindex");
       WhiteList.add("vssrid");
       WhiteList.add("vstab");
       WhiteList.add("vstopics");
       WhiteList.add("vstype");
       WhiteList.add("vsuser");
       WhiteList.add("vsversion");
       WhiteList.add("vsvid");
       WhiteList.add("vswid");
       WhiteList.add("wealthscripttype");
       WhiteList.add("webexp");
       WhiteList.add("withdrawalfrom");
       WhiteList.add("wsattr");
       WhiteList.add("wscode");
       WhiteList.add("wspmflfund");
       WhiteList.add("yplanding");

       requestQuery = requestQuery.toLowerCase();
       if ((requestQuery != null) && (requestQuery.length() > 0))
       {
    	   //requestQuery = requestQuery.substring(1);
    	   //requestQuery = requestQuery.substring(0,requestQuery.length()-1); 
       
           String[] NameValuePairs = requestQuery.split("\\&");
       

           for (int k=0; k<NameValuePairs.length; k++) { 
        	   String nameValuePair = NameValuePairs[k];
        	   String[] nameValueArray = NameValuePairs[k].split("\\=");
        	   
        	   if ((nameValueArray.length > 0) && (WhiteList.contains(nameValueArray[0]))) {
        		   newQuery = newQuery.concat(nameValuePair + "&");
        	   }
           }
           
           if (newQuery.length() > 0) {newQuery = newQuery.substring(0,newQuery.length()-1); }
       }
       else
       {
    	   newQuery = requestQuery;
       }
       return (newQuery.equals("")?"-":newQuery); //FIXME
	}
}
