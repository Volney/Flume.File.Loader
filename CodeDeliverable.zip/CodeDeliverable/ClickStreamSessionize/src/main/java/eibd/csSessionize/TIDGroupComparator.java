package eibd.csSessionize;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class TIDGroupComparator extends WritableComparator{

	protected TIDGroupComparator() {
		super(TIDCompositeKey.class, true);
	}

	@Override
	public int compare(WritableComparable o1, WritableComparable o2) {

		TIDCompositeKey tidK1 = (TIDCompositeKey) o1;
		TIDCompositeKey tidK2 = (TIDCompositeKey) o2;

		return tidK1.getTid().compareTo(tidK2.getTid());

	}
	

}
