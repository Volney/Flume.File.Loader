package eibd.csSessionize;


import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

/**
 * CompositeKeyComparator
 * 
 * Purpose: Compares two WriteableComparables
 * 
 * When we are sorting keys, in this case we only want to sort by group ids in
 * that we want all of the same group ids grouped together regardless of the
 * timestamp portion of their key. This functionality is provided by the
 * NaturalKeyGroupingComparator class
 * 
 * Inside the set of k/v pairs in this group, in this secondary sort example we
 * want to sort on the second half of the key (TimeseriesKey) which is the
 * purpose of this class.
 * 
 * 
 * @author jpatterson
 * 
 */
public class CompositeKeyComparator extends WritableComparator {

	public CompositeKeyComparator() {
		super(TIDCompositeKey.class, true);
	}

	@Override
	public int compare(WritableComparable w1, WritableComparable w2) {

		TIDCompositeKey tk1 = (TIDCompositeKey) w1;
		TIDCompositeKey tk2 = (TIDCompositeKey) w2;

		/*int cmp = ip1.getTid().compareTo(ip2.getTid());
		if (cmp != 0) {
			return cmp;
		}

		return ip1.getTimestamp() == ip2.getTimestamp() ? 0 : (ip1
				.getTimestamp() < ip2.getTimestamp() ? 1 : -1);*/

		return(tk1.compareTo(tk2));
	}

}
