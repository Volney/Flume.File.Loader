package eibd.csSessionize;

import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import eibd.csSessionize.TIDCompositeKey;

public class AM {

	private String theMID = "-"; //sujit - initialize
	private String theTID = "-";
	private String relMap = "-";
	private String role = "-";
	private String sessionKey = "-";
	private String mimedMID = "-";
	
	// private constructor - force parsing through static parse() method
	private AM() {	}
	
	public static void main(String[] args) {
		String inputStr = "72.130.84.83	-	-	[24/Nov/2011:00:14:38 -0500]	200	19640	\"https://www.fidelity.com/\"	\"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.2 (KHTML, like Gecko) Chrome/15.0.874.121 Safari/535.2\"	GET	\"/ftgw/fbc/ofsummary/summary\"	\"-\"	HTTP/1.1	1197.190	\"-\"	-	-	REQ4ecdd2bc0a0429a0200023ae0001aa33	10.4.40.163	<AM status='Success' subStatus='Success' reason=''><COMMON PATTERN='.FidCust' FSREQID='REQ4ecdd2bc0a0429a0200023ae0001aa33' TRACKER_ID='4e460a800a0328ee200026630003aa33'/><WEBSTATS REALM='Retail' ROLE='FidCust' MID='eed4c77b827c0c11d6b90f9bc8b54aaa77' RELMAP='0e' SESSION_KEY='4ecdd2bc0a060c7c2000004a0002aa330000' AUTH_METHOD='RtlCust'/><FEBSEC CTIME='1322111676'/></AM>	impressions=";
		AM foo = AM.parse(inputStr);
		System.out.println("MID: " + foo.getTheMID());
		System.out.println("TID: " + foo.getTheTID());
		System.out.println("ROLE: " + foo.getRole());
		
		TIDCompositeKey tid = new TIDCompositeKey();
		tid.set(foo.getTheTID(), new Date().getTime(), foo.getTheMID());
		System.out.println(tid);
	}
	

	// look for instance of MID='*' on a line
	static Pattern pattern = Pattern.compile("TRACKER_ID=\'([^\']+)\'.+ROLE=\'([^\']+)\'.+MID=\'([^\']+)\'.+RELMAP=\'([^\']+)\'.+SESSION_KEY=\'([^\']+)\'");
	
	public static AM parse(String AMLine) {
		

        // Determine if pattern exists in input
        CharSequence inputStr = AMLine;
        Matcher matcher = pattern.matcher(inputStr);
        
        AM theAM = new AM();
        
        boolean matchFound = matcher.find();    // true
        if (matchFound) {
            // Get all groups for this match
            theAM.theTID= matcher.group(1);
            theAM.role = matcher.group(2);
            String midString = matcher.group(3);

        	int midDivider = midString.indexOf(":");
        	// check if MID match has a colon - if so, first half is mimeMID
        	
        	if (midDivider == -1 ) { // the regex match is the mid, proper.
        		theAM.theMID = midString;
        	} else {  // we want the second half of the REPID:CUSTID string
        		theAM.theMID = midString.substring(midDivider+1);
        		theAM.mimedMID = midString.substring(0, midDivider);
        	}
        	
            theAM.relMap = matcher.group(4);
            theAM.sessionKey = matcher.group(5);
        }
        return theAM;
 	}

	public String getTheMID() {
		return theMID;
	}

	public String getTheTID() {
		return theTID;
	}

	public String getRelMap() {
		return relMap;
	}

	public String getRole() {
		return role;
	}

	public String getSessionKey() {
		return sessionKey;
	}

	public String getMimedMID() {
		return mimedMID;
	}
}