package eibd.csSessionize;

import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.Partitioner;

public class TIDPartitioner implements Partitioner<TIDCompositeKey, OmnitureWritable> {
	
	public int getPartition(TIDCompositeKey key, OmnitureWritable value,
			int numPartitions) {
		return Math.abs(key.getTid().hashCode() % numPartitions);
	}

	@Override
	public void configure(JobConf arg0) {
		// TODO Auto-generated method stub
		
	}

	

}
