package eibd.csSessionize;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.regex.Pattern;

import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.FileSplit;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

public class TrafficGroupingMapper extends MapReduceBase 
		implements Mapper<Writable, Text, TIDCompositeKey, OmnitureWritable> {

	private TIDCompositeKey tid = new TIDCompositeKey();
	private boolean noise = false;
	private OmnitureWritable omniWrite = new OmnitureWritable();
	private static String dCacheName = "blacklist_urls.txt";
	private HashSet<String> urls = new HashSet<String>();
	
	public void configure(JobConf job) {
    	// Get the cached archives/files
        /* JT - TITAN: no URL filters.  DC not needed.
         * try {
     	   Path[] cacheFiles = DistributedCache.getLocalCacheFiles(job);
     	   if (cacheFiles != null && cacheFiles.length > 0) {
     		   for (Path filePath : cacheFiles) {   
     			   if (filePath.getName().equals(dCacheName)) {
     				   loadUrls(filePath);
     			   }
     		   }
     	   }
        } catch (IOException e) {
        	e.printStackTrace();
        }*/
    }
	
	/*private void loadUrls(Path filePath) throws IOException {
		BufferedReader fileReader = new BufferedReader(new FileReader(
				filePath.toString()));
		try {
			String line;
			this.urls = new HashSet<String>();
			while ((line = fileReader.readLine()) != null) {
				this.urls.add(line.toLowerCase());
			}
		} finally {
			fileReader.close();
		}
	}*/
	
	Pattern tabPattern = Pattern.compile("\t");
	Pattern pipePattern = Pattern.compile("\\|");
	
	//The following values are for finding unparsable rows.
	HashMap<String, String> unParseableRowMap = new HashMap<String, String>();
	int reportCounter = 0;
	
	public void reportFilteredRow(String currentLine, String unParsableReason) {
		if (reportCounter < 20) {
			
			String[] lineSplit = pipePattern.split(currentLine);
			String filename = "n/a";
			if (lineSplit.length > 1) {
				filename = lineSplit[0];
			}
			if (unParseableRowMap.get(filename) == null && unParseableRowMap.size() < 20) {
				reportCounter++;
				
				unParseableRowMap.put(filename, currentLine);
				System.err.println("Unable to parse row from:" + filename);
				System.err.println(currentLine);
				System.err.println("Reason for parse failure was:" + unParsableReason);
			}
		}
	}
	
	public void map(Writable key, Text value,
		      OutputCollector<TIDCompositeKey, OmnitureWritable> output, Reporter reporter)
		      throws IOException {
		
		String theLine = value.toString();
		
		String[] foo = theLine.split("\t");
		if (foo.length < 18) {
			reporter.getCounter("Mapper", "foo.length < 18").increment(1);
			
			reportFilteredRow(theLine, "Split by tab has less then 18 parts");
			
			return; // FIXME	
		}
		if (foo[3].length() != 28) { 
			reporter.getCounter("Mapper", "foo[3].length != 28").increment(1);
			
			reportFilteredRow(theLine, "split 3 is not a valid date because the length is not 28");
			
			return;
		}
		
		//FIXME - separate logic for filter... converge it in parsing class
		//Ted - Note used ////String requestWithQuery = (foo[9]+"?"+foo[10]).replaceAll("\\\"", "").toLowerCase();
		//Ted - Note used ////String agent = foo[7].replaceAll("\\\"", "").toLowerCase();
		
		String method = foo[8].replaceAll("\\\"", "").toLowerCase();
		if (!(method.contains("get") || method.contains("post"))) {
			reporter.getCounter("Mapper", "RejMethod:" + method).increment(1);
			
			reportFilteredRow(theLine, "method is not get or post but:" + method);
			
			return;
		}
		
		//Ted - Note used //FileSplit fileSplit = (FileSplit)reporter.getInputSplit();
		//Ted - Note used ////String fileName = fileSplit.getPath().getName();
		String domainName = "";  // FIXME sanitize input name
//		String domainName = fileName.substring(0, fileName.indexOf("."))+ ".fidelity.com";  // FIXME sanitize input name
//		String blackList = (fileName+":"+foo[9]).replaceAll("\\\"", "").toLowerCase();

		//check for noise...
		// if the url matches the blacklist, or if it matches the filter rules... -> noise
//		noise = ( (urls.contains(blackList)) ) || (Filter.testForFilter(requestWithQuery, agent, fileName));
		
		int writeOutCount = 10;
		
		noise = false;
		if (!noise) { // if there's noise, don't emit
			try
			{
				omniWrite.set(foo);
	//			if (omniWrite.getTid() == "-") return;
				omniWrite.setRequestPageStr(domainName+omniWrite.getRequestPageStr()); // append domain name
				omniWrite.setRequestDynamicStr(Filter.filterClickpairs(omniWrite.getRequestDynamicStr().toLowerCase()));  // clickpair method
				String theTID = omniWrite.getTid();
				long theTime = omniWrite.getClickDate();
				String theMID = omniWrite.getMid();
				if(theTID.length() > 1) {
					tid.set(theTID, theTime, theMID);
					output.collect(tid, omniWrite);
				} else {
					reportFilteredRow(theLine, "theTID length is not > 1");
					reporter.getCounter("Mapper", "theTID length is not > 1").increment(1);
				}
					
				
				if (writeOutCount-- > 0){
					System.out.println("O-" + theLine);
					System.out.println("N-" + tid.toString());
					System.out.println("N1-" + omniWrite.toString());
				}
				
			} catch (Exception e) {
				reportFilteredRow(theLine, "Exception:" + e.getMessage());
				reporter.getCounter("Mapper", "Exception:").increment(1);
			}
		} else {
			reportFilteredRow(theLine, "Noise");
			reporter.getCounter("Mapper", "noise").increment(1);
		}
	} 
} 