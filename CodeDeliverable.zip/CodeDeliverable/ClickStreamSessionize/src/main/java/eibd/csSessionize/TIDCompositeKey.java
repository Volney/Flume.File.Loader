package eibd.csSessionize;


import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Date;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;


public class TIDCompositeKey implements WritableComparable<TIDCompositeKey> {
	
	private String Tid = "";
	private long Timestamp = 0;
	private String Mid = "";
	
	public String toString() {
		return Tid + ": " + new Date(Timestamp).toString() + ": " + Mid;
	}
	
	public void fromOmnitureWritable(OmnitureWritable ow){
		this.Tid = ow.getTid();
		this.Timestamp = ow.getClickDate();
		this.Mid = ow.getMid();
	}
	
	public void set(String tid, long ts, String Mid) {
		this.Tid = tid;
		this.Timestamp = ts;
		this.Mid = Mid;
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		this.Tid = in.readUTF();
		this.Timestamp = in.readLong();
		this.Mid = in.readUTF();
	}

	@Override
	public void write(DataOutput out) throws IOException {
		out.writeUTF(this.Tid);
		out.writeLong(this.Timestamp);
		out.writeUTF(this.Mid);
	}

	@Override
	public int compareTo(TIDCompositeKey other) {
		if (this.Tid.compareTo(other.Tid) != 0) { // Tid ascending
			return this.Tid.compareTo(other.Tid);
		} else if(this.Timestamp != other.Timestamp) { 	// Timestamp descending 
			return this.Timestamp < other.Timestamp ? 1 : -1;
		}
		// Mid ascending
		else if(this.Mid.compareTo(other.Mid) != 0 ){
			return this.Mid.compareTo(other.Mid);
		}
		else{
			return 0;
		}
		
	}
	
	public String getTid() {
		return Tid;
	}

	public void setTid(String tid) {
		Tid = tid;
	}

	public long getTimestamp() {
		return Timestamp;
	}

	public void setTimestamp(long timestamp) {
		Timestamp = timestamp;
	}

	public String getMid() {
		return Mid;
	}

	public void setMid(String mid) {
		Mid = mid;
	}

	@Override
	public int hashCode() {
		return this.Tid.hashCode();
	}
	
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return this.Tid.equals(((TIDCompositeKey)obj).Tid);
	}
	
	
/*
	public static class TidCompositeKeyComparator extends WritableComparator {
		public TidCompositeKeyComparator() {
			super(TIDCompositeKey.class);
		}

		public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {
			return compareBytes(b1, s1, l1, b2, s2, l2);
		}
		public int compare(WritableComparable w1, WritableComparable w2) {
			
			int comp = w1.compareTo(w2);
			return comp;
			
			
		}
	}
*/
/*	static { // register this comparator
		WritableComparator.define(TIDCompositeKey.class,
				new TidCompositeKeyComparator());
	}
*/
}
